import math
import os
import json
from mesh_base import Mesh

def init_materials(mesh):
    # Palette tailored to match the low-poly cozy greenhouse reference
    mesh.register_material("pot_terracotta", [0.85, 0.44, 0.32], roughness=0.7) # #D97052
    mesh.register_material("pot_rim",        [0.90, 0.48, 0.35], roughness=0.6) # #E67A59
    mesh.register_material("soil",           [0.26, 0.16, 0.10], roughness=0.9) # #42291A
    mesh.register_material("face_feature",   [0.10, 0.08, 0.08], roughness=0.4) # #1A1414
    mesh.register_material("blush",          [0.95, 0.52, 0.52], roughness=0.8) # #F28482
    mesh.register_material("wood_stake",     [0.76, 0.64, 0.48], roughness=0.8) # #C2A37A
    mesh.register_material("twine_tie",      [0.90, 0.85, 0.70], roughness=0.7) # #E6D9B3
    mesh.register_material("stem",           [0.42, 0.65, 0.22], roughness=0.5) # #6BA638
    mesh.register_material("leaf",           [0.34, 0.58, 0.18], roughness=0.6) # #57942E
    mesh.register_material("leaf_light",     [0.48, 0.72, 0.24], roughness=0.6) # #7AB83D
    mesh.register_material("tomato_red",     [0.90, 0.16, 0.14], roughness=0.3, specular=[0.3, 0.3, 0.3]) # #E62924
    mesh.register_material("tomato_ripe",    [0.82, 0.12, 0.10], roughness=0.3, specular=[0.4, 0.4, 0.4]) # #D11F1A
    mesh.register_material("tomato_green",   [0.55, 0.75, 0.32], roughness=0.4) # #8CBF52
    mesh.register_material("calyx",          [0.40, 0.62, 0.20], roughness=0.5) # #669E33
    mesh.register_material("flower_petal",   [1.00, 0.82, 0.15], roughness=0.4) # #FFD126
    mesh.register_material("flower_center",  [0.60, 0.75, 0.20], roughness=0.5) # #99BF33
    mesh.register_material("bench_wood",     [0.68, 0.52, 0.36], roughness=0.8) # #AE855C

def add_pot_with_face(mesh, center=(0, 0, 0)):
    cx, cy, cz = center
    
    # 10-sided faceted pot body
    segs = 10
    r_base = 0.58
    r_top = 0.85
    y_base = cy
    y_top = cy + 1.25
    mesh.add_cylinder([cx, y_base, cz], [cx, y_top, cz], r_base, r_top, segments=segs, mat_name="pot_terracotta")
    
    # Base disk
    mesh.add_disk([cx, y_base, cz], r_base, [0, -1, 0], segments=segs, mat_name="pot_terracotta")
    
    # Rim / collar (slightly thicker, overlapping top)
    r_rim_out = 0.94
    y_rim_bot = cy + 1.20
    y_rim_top = cy + 1.50
    mesh.add_cylinder([cx, y_rim_bot, cz], [cx, y_rim_top, cz], r_rim_out, r_rim_out, segments=segs, mat_name="pot_rim")
    
    # Rim top annular flange to inside soil
    r_soil = 0.82
    y_soil = cy + 1.35
    # Inner wall of rim (facing inward)
    mesh.add_cylinder([cx, y_rim_top, cz], [cx, y_soil, cz], r_soil, r_soil, segments=segs, mat_name="pot_rim")
    
    # Top rim ring (facing up)
    top_rim_outer = []
    top_rim_inner = []
    for i in range(segs):
        ang = 2.0 * math.pi * i / segs
        top_rim_outer.append([cx + math.cos(ang)*r_rim_out, y_rim_top, cz + math.sin(ang)*r_rim_out])
        top_rim_inner.append([cx + math.cos(ang)*r_soil, y_rim_top, cz + math.sin(ang)*r_soil])
    for i in range(segs):
        next_i = (i + 1) % segs
        mesh.add_quad(top_rim_outer[i], top_rim_inner[i], top_rim_inner[next_i], top_rim_outer[next_i], "pot_rim")
        
    # Dark rich potting soil (facing up)
    mesh.add_disk([cx, y_soil, cz], r_soil, [0, 1, 0], segments=segs, mat_name="soil")
    
    # Cute Face on front side (towards +Z)
    eye_y = cy + 0.78
    t = (eye_y - y_base) / (y_top - y_base)
    r_at_eye = r_base + t * (r_top - r_base)
    
    # Eye distance
    eye_x_offset = 0.22
    eye_z = cz + math.sqrt(max(0.01, r_at_eye**2 - eye_x_offset**2)) + 0.04
    
    # Two small round eyes
    mesh.add_sphere([cx - eye_x_offset, eye_y, eye_z], 0.055, lat_segs=5, lon_segs=6, mat_name="face_feature", squash_y=1.1)
    mesh.add_sphere([cx + eye_x_offset, eye_y, eye_z], 0.055, lat_segs=5, lon_segs=6, mat_name="face_feature", squash_y=1.1)
    
    # Cute little smile: curved strip of vertices
    mouth_y = cy + 0.65
    mouth_pts = [
        [-0.14, mouth_y + 0.045],
        [-0.07, mouth_y + 0.010],
        [0.00,  mouth_y],
        [0.07,  mouth_y + 0.010],
        [0.14,  mouth_y + 0.045]
    ]
    for i in range(len(mouth_pts) - 1):
        x1, y1 = mouth_pts[i]
        x2, y2 = mouth_pts[i+1]
        z1 = cz + r_at_eye * 0.98 + 0.04
        z2 = cz + r_at_eye * 0.98 + 0.04
        mesh.add_cylinder([cx + x1, y1, z1], [cx + x2, y2, z2], 0.018, 0.018, segments=4, mat_name="face_feature")
        
    # Soft pink blush cheeks
    blush_y = cy + 0.70
    blush_x = 0.38
    blush_z = cz + math.sqrt(max(0.01, r_at_eye**2 - blush_x**2)) + 0.04
    mesh.add_sphere([cx - blush_x, blush_y, blush_z], 0.065, lat_segs=4, lon_segs=6, mat_name="blush", squash_y=0.7)
    mesh.add_sphere([cx + blush_x, blush_y, blush_z], 0.065, lat_segs=4, lon_segs=6, mat_name="blush", squash_y=0.7)


def build_stage1(center=(0, 0, 0)):
    # STAGE 1: Cute Sprout (Росток)
    cx, cy, cz = center
    mesh = Mesh("tomato_stage1_sprout")
    init_materials(mesh)
    add_pot_with_face(mesh, center)
    
    y_soil = cy + 1.35
    # Small stem poking up from soil with subtle curve
    p0 = [cx, y_soil, cz]
    p1 = [cx + 0.02, y_soil + 0.45, cz + 0.02]
    p2 = [cx, y_soil + 0.85, cz]
    mesh.add_cylinder(p0, p1, 0.050, 0.045, segments=6, mat_name="stem")
    mesh.add_cylinder(p1, p2, 0.045, 0.038, segments=6, mat_name="stem")
    
    # Two wide oval cotyledon leaves (семядоли)
    # Left leaf
    mesh.add_leaf(base=p2, tip=[cx - 0.48, y_soil + 0.98, cz + 0.05], normal=[0, 1, 0.3], width=0.28, mat_name="leaf_light", fold=0.20)
    # Right leaf
    mesh.add_leaf(base=p2, tip=[cx + 0.48, y_soil + 0.98, cz - 0.05], normal=[0, 1, -0.3], width=0.28, mat_name="leaf_light", fold=0.20)
    
    # Tiny emerging first true leaves at the top
    p_top = [cx, y_soil + 0.92, cz]
    mesh.add_cylinder(p2, p_top, 0.038, 0.028, segments=5, mat_name="stem")
    mesh.add_leaf(base=p_top, tip=[cx + 0.05, y_soil + 1.15, cz + 0.22], normal=[0.2, 0.8, 0.6], width=0.15, mat_name="leaf", fold=0.15)
    mesh.add_leaf(base=p_top, tip=[cx - 0.05, y_soil + 1.15, cz - 0.22], normal=[-0.2, 0.8, -0.6], width=0.15, mat_name="leaf", fold=0.15)
    
    return mesh


def build_stage2(center=(0, 0, 0)):
    # STAGE 2: Growing Tomato Bush with Flowers and Green Baby Tomatoes (Подросший куст / цветение)
    cx, cy, cz = center
    mesh = Mesh("tomato_stage2_flowering")
    init_materials(mesh)
    add_pot_with_face(mesh, center)
    
    y_soil = cy + 1.35
    
    # Wooden support stake (bamboo stick)
    stake_p0 = [cx - 0.16, y_soil - 0.1, cz - 0.12]
    stake_p1 = [cx - 0.16, y_soil + 2.50, cz - 0.12]
    mesh.add_cylinder(stake_p0, stake_p1, 0.038, 0.035, segments=6, mat_name="wood_stake")
    
    # Main stem (taller, segmented with organic slight curve)
    stem_pts = [
        [cx, y_soil, cz],
        [cx - 0.03, y_soil + 0.6, cz - 0.02],
        [cx - 0.08, y_soil + 1.2, cz - 0.05],
        [cx - 0.04, y_soil + 1.8, cz - 0.02],
        [cx + 0.02, y_soil + 2.3, cz + 0.02]
    ]
    for i in range(len(stem_pts) - 1):
        r1 = 0.065 - i * 0.007
        r2 = 0.065 - (i + 1) * 0.007
        mesh.add_cylinder(stem_pts[i], stem_pts[i+1], r1, r2, segments=6, mat_name="stem")
        
    # Twine ties attaching stem to bamboo stake at two heights
    for tie_y in [y_soil + 0.9, y_soil + 1.6]:
        mesh.add_cylinder([cx - 0.16, tie_y, cz - 0.12], [cx - 0.06, tie_y, cz - 0.04], 0.016, 0.016, segments=4, mat_name="twine_tie")

    # Branch 1 (Lower Left-Forward)
    b1_start = stem_pts[1]
    b1_end = [cx - 0.45, y_soil + 0.85, cz + 0.35]
    mesh.add_cylinder(b1_start, b1_end, 0.035, 0.025, segments=5, mat_name="stem")
    # Leaflets on branch 1
    mesh.add_leaf(b1_end, [cx - 0.72, y_soil + 0.95, cz + 0.55], [0, 1, 0.3], 0.26, "leaf", fold=0.2)
    mesh.add_leaf([cx - 0.25, y_soil + 0.75, cz + 0.18], [cx - 0.50, y_soil + 0.70, cz + 0.08], [0.3, 0.9, 0], 0.22, "leaf", fold=0.18)
    mesh.add_leaf([cx - 0.35, y_soil + 0.80, cz + 0.26], [cx - 0.30, y_soil + 0.80, cz + 0.50], [-0.3, 0.9, 0], 0.22, "leaf", fold=0.18)

    # Branch 2 (Mid Right-Backward)
    b2_start = stem_pts[2]
    b2_end = [cx + 0.50, y_soil + 1.40, cz - 0.25]
    mesh.add_cylinder(b2_start, b2_end, 0.035, 0.025, segments=5, mat_name="stem")
    mesh.add_leaf(b2_end, [cx + 0.82, y_soil + 1.50, cz - 0.38], [0, 1, -0.3], 0.28, "leaf", fold=0.2)
    mesh.add_leaf([cx + 0.22, y_soil + 1.30, cz - 0.12], [cx + 0.42, y_soil + 1.25, cz + 0.10], [-0.3, 0.9, 0.2], 0.22, "leaf", fold=0.18)
    mesh.add_leaf([cx + 0.36, y_soil + 1.35, cz - 0.18], [cx + 0.30, y_soil + 1.38, cz - 0.45], [0.3, 0.9, -0.2], 0.22, "leaf", fold=0.18)

    # Branch 3 (Forward Right with baby green tomato)
    b3_start = [cx - 0.06, y_soil + 1.50, cz - 0.03]
    b3_end = [cx + 0.32, y_soil + 1.75, cz + 0.32]
    mesh.add_cylinder(b3_start, b3_end, 0.032, 0.022, segments=5, mat_name="stem")
    mesh.add_leaf(b3_end, [cx + 0.58, y_soil + 1.88, cz + 0.50], [0, 1, 0.4], 0.26, "leaf", fold=0.18)
    
    # 1 Cute Baby Green Tomato hanging below branch 3!
    pedicel_start = [cx + 0.20, y_soil + 1.62, cz + 0.20]
    tomato_pos = [cx + 0.22, y_soil + 1.45, cz + 0.24]
    mesh.add_cylinder(pedicel_start, tomato_pos, 0.016, 0.014, segments=4, mat_name="calyx")
    mesh.add_star_calyx(tomato_pos, stem_dir=[0, 1, 0], radius=0.12, points=5, mat_name="calyx")
    mesh.add_sphere(tomato_pos, 0.14, lat_segs=6, lon_segs=8, mat_name="tomato_green", squash_y=0.9)

    # Branch 4 (Upper Left with bright yellow flowers)
    b4_start = stem_pts[3]
    b4_end = [cx - 0.38, y_soil + 2.05, cz + 0.15]
    mesh.add_cylinder(b4_start, b4_end, 0.030, 0.020, segments=5, mat_name="stem")
    mesh.add_leaf(b4_end, [cx - 0.60, y_soil + 2.20, cz + 0.28], [0.2, 0.9, 0.2], 0.24, "leaf", fold=0.18)
    
    # Cluster of 2 bright yellow tomato flowers!
    fl_pos1 = [cx - 0.24, y_soil + 2.02, cz + 0.28]
    fl_pos2 = [cx - 0.32, y_soil + 1.95, cz + 0.35]
    mesh.add_cylinder([cx - 0.20, y_soil + 1.95, cz + 0.10], fl_pos1, 0.014, 0.012, segments=4, mat_name="calyx")
    mesh.add_cylinder([cx - 0.20, y_soil + 1.95, cz + 0.10], fl_pos2, 0.014, 0.012, segments=4, mat_name="calyx")
    mesh.add_flower(fl_pos1, dir_v=[0.2, 0.4, 0.9], size=0.12)
    mesh.add_flower(fl_pos2, dir_v=[-0.3, 0.3, 0.9], size=0.10)

    # Top apex leaves
    mesh.add_leaf(stem_pts[4], [cx + 0.05, y_soil + 2.62, cz + 0.15], [0, 0.9, 0.4], 0.22, "leaf_light", fold=0.18)
    mesh.add_leaf(stem_pts[4], [cx - 0.15, y_soil + 2.58, cz - 0.15], [-0.3, 0.9, -0.3], 0.20, "leaf_light", fold=0.18)

    return mesh


def build_stage3(center=(0, 0, 0)):
    # STAGE 3: Full Mature Fruiting Tomato Plant with Red Ripe Tomatoes (Взрослый плодоносящий куст)
    # Perfectly matches the left-most pot in the user's reference image!
    cx, cy, cz = center
    mesh = Mesh("tomato_stage3_mature")
    init_materials(mesh)
    add_pot_with_face(mesh, center)
    
    y_soil = cy + 1.35
    
    # Wooden support stake
    stake_p0 = [cx - 0.14, y_soil - 0.1, cz - 0.14]
    stake_p1 = [cx - 0.14, y_soil + 3.20, cz - 0.14]
    mesh.add_cylinder(stake_p0, stake_p1, 0.042, 0.036, segments=6, mat_name="wood_stake")

    # Main sturdy stem
    stem_pts = [
        [cx, y_soil, cz],
        [cx - 0.02, y_soil + 0.70, cz - 0.03],
        [cx - 0.08, y_soil + 1.40, cz - 0.06],
        [cx - 0.05, y_soil + 2.10, cz - 0.04],
        [cx + 0.02, y_soil + 2.75, cz + 0.01],
        [cx, y_soil + 3.10, cz]
    ]
    for i in range(len(stem_pts) - 1):
        r1 = 0.075 - i * 0.008
        r2 = 0.075 - (i + 1) * 0.008
        mesh.add_cylinder(stem_pts[i], stem_pts[i+1], r1, r2, segments=6, mat_name="stem")

    # Support ties (twine loops) at 3 levels
    for tie_y in [y_soil + 0.90, y_soil + 1.70, y_soil + 2.50]:
        mesh.add_cylinder([cx - 0.14, tie_y, cz - 0.14], [cx - 0.06, tie_y, cz - 0.04], 0.016, 0.016, segments=4, mat_name="twine_tie")

    # --- TOMATOES (Ripe red & green) matching the reference picture! ---
    
    # TOMATO 1: Large prime ripe red tomato (Lower Left)
    t1_pedicel_top = [cx - 0.05, y_soil + 1.25, cz + 0.05]
    t1_pos = [cx - 0.38, y_soil + 1.05, cz + 0.36]
    mesh.add_cylinder(t1_pedicel_top, [cx - 0.38, y_soil + 1.20, cz + 0.36], 0.022, 0.018, segments=4, mat_name="stem")
    mesh.add_cylinder([cx - 0.38, y_soil + 1.20, cz + 0.36], t1_pos, 0.020, 0.016, segments=4, mat_name="calyx")
    mesh.add_star_calyx(t1_pos, stem_dir=[0, 1, 0], radius=0.22, points=5, mat_name="calyx")
    mesh.add_sphere(t1_pos, 0.28, lat_segs=8, lon_segs=10, mat_name="tomato_red", squash_y=0.88)

    # TOMATO 2: Medium-large ripe red tomato (Lower Right)
    t2_pedicel_top = [cx + 0.02, y_soil + 1.15, cz + 0.08]
    t2_pos = [cx + 0.40, y_soil + 0.98, cz + 0.32]
    mesh.add_cylinder(t2_pedicel_top, [cx + 0.40, y_soil + 1.12, cz + 0.32], 0.020, 0.016, segments=4, mat_name="stem")
    mesh.add_cylinder([cx + 0.40, y_soil + 1.12, cz + 0.32], t2_pos, 0.018, 0.015, segments=4, mat_name="calyx")
    mesh.add_star_calyx(t2_pos, stem_dir=[0, 1, 0], radius=0.20, points=5, mat_name="calyx")
    mesh.add_sphere(t2_pos, 0.25, lat_segs=8, lon_segs=10, mat_name="tomato_ripe", squash_y=0.88)

    # TOMATO 3: Medium ripe red tomato (Mid Left/Center)
    t3_pedicel_top = [cx - 0.06, y_soil + 1.85, cz + 0.02]
    t3_pos = [cx - 0.28, y_soil + 1.70, cz + 0.38]
    mesh.add_cylinder(t3_pedicel_top, [cx - 0.28, y_soil + 1.80, cz + 0.38], 0.018, 0.015, segments=4, mat_name="stem")
    mesh.add_cylinder([cx - 0.28, y_soil + 1.80, cz + 0.38], t3_pos, 0.016, 0.014, segments=4, mat_name="calyx")
    mesh.add_star_calyx(t3_pos, stem_dir=[0, 1, 0], radius=0.18, points=5, mat_name="calyx")
    mesh.add_sphere(t3_pos, 0.22, lat_segs=8, lon_segs=10, mat_name="tomato_red", squash_y=0.88)

    # TOMATO 4: Ripening green/orange tomato (Mid Upper Right)
    t4_pedicel_top = [cx + 0.01, y_soil + 2.20, cz + 0.02]
    t4_pos = [cx + 0.28, y_soil + 2.05, cz + 0.28]
    mesh.add_cylinder(t4_pedicel_top, t4_pos, 0.016, 0.014, segments=4, mat_name="calyx")
    mesh.add_star_calyx(t4_pos, stem_dir=[0, 1, 0], radius=0.14, points=5, mat_name="calyx")
    mesh.add_sphere(t4_pos, 0.17, lat_segs=6, lon_segs=8, mat_name="tomato_green", squash_y=0.88)

    # --- RICH FOLIAGE BRANCHES ---
    
    # Branch 1 (Low Left spreading)
    b1_start = stem_pts[1]
    b1_mid = [cx - 0.40, y_soil + 1.05, cz - 0.10]
    b1_end = [cx - 0.75, y_soil + 1.25, cz + 0.05]
    mesh.add_cylinder(b1_start, b1_mid, 0.040, 0.030, segments=5, mat_name="stem")
    mesh.add_cylinder(b1_mid, b1_end, 0.030, 0.022, segments=5, mat_name="stem")
    mesh.add_leaf(b1_end, [cx - 1.05, y_soil + 1.35, cz + 0.15], [0, 1, 0.2], 0.32, "leaf", fold=0.22)
    mesh.add_leaf(b1_mid, [cx - 0.55, y_soil + 0.95, cz - 0.35], [-0.3, 0.9, -0.3], 0.26, "leaf", fold=0.2)
    mesh.add_leaf(b1_mid, [cx - 0.65, y_soil + 1.20, cz + 0.30], [0.3, 0.9, 0.3], 0.26, "leaf", fold=0.2)

    # Branch 2 (Low Right spreading)
    b2_start = stem_pts[1]
    b2_mid = [cx + 0.45, y_soil + 1.00, cz - 0.15]
    b2_end = [cx + 0.80, y_soil + 1.18, cz + 0.05]
    mesh.add_cylinder(b2_start, b2_mid, 0.040, 0.030, segments=5, mat_name="stem")
    mesh.add_cylinder(b2_mid, b2_end, 0.030, 0.022, segments=5, mat_name="stem")
    mesh.add_leaf(b2_end, [cx + 1.10, y_soil + 1.25, cz + 0.15], [0, 1, 0.2], 0.32, "leaf", fold=0.22)
    mesh.add_leaf(b2_mid, [cx + 0.60, y_soil + 0.90, cz - 0.40], [0.3, 0.9, -0.3], 0.26, "leaf", fold=0.2)
    mesh.add_leaf(b2_mid, [cx + 0.70, y_soil + 1.15, cz + 0.30], [-0.3, 0.9, 0.3], 0.26, "leaf", fold=0.2)

    # Branch 3 (Mid Back Right)
    b3_start = stem_pts[2]
    b3_end = [cx + 0.50, y_soil + 1.75, cz - 0.40]
    mesh.add_cylinder(b3_start, b3_end, 0.035, 0.025, segments=5, mat_name="stem")
    mesh.add_leaf(b3_end, [cx + 0.78, y_soil + 1.90, cz - 0.60], [0, 1, -0.4], 0.30, "leaf", fold=0.2)
    mesh.add_leaf([cx + 0.25, y_soil + 1.60, cz - 0.25], [cx + 0.35, y_soil + 1.70, cz - 0.55], [0.2, 0.9, -0.3], 0.25, "leaf", fold=0.18)

    # Branch 4 (Mid Back Left)
    b4_start = stem_pts[2]
    b4_end = [cx - 0.52, y_soil + 1.80, cz - 0.35]
    mesh.add_cylinder(b4_start, b4_end, 0.035, 0.025, segments=5, mat_name="stem")
    mesh.add_leaf(b4_end, [cx - 0.82, y_soil + 1.95, cz - 0.52], [0, 1, -0.4], 0.30, "leaf", fold=0.2)
    mesh.add_leaf([cx - 0.28, y_soil + 1.65, cz - 0.22], [cx - 0.40, y_soil + 1.75, cz - 0.50], [-0.2, 0.9, -0.3], 0.25, "leaf", fold=0.18)

    # Branch 5 (Upper Forward Left with flowers)
    b5_start = stem_pts[3]
    b5_end = [cx - 0.42, y_soil + 2.50, cz + 0.25]
    mesh.add_cylinder(b5_start, b5_end, 0.032, 0.022, segments=5, mat_name="stem")
    mesh.add_leaf(b5_end, [cx - 0.68, y_soil + 2.70, cz + 0.38], [0.2, 0.9, 0.3], 0.28, "leaf", fold=0.2)
    
    # 2 small blossoms at the top
    fl_pos = [cx - 0.26, y_soil + 2.55, cz + 0.35]
    mesh.add_cylinder([cx - 0.20, y_soil + 2.45, cz + 0.15], fl_pos, 0.014, 0.012, segments=4, mat_name="calyx")
    mesh.add_flower(fl_pos, dir_v=[0.2, 0.4, 0.9], size=0.13)

    # Branch 6 (Upper Forward Right)
    b6_start = stem_pts[3]
    b6_end = [cx + 0.40, y_soil + 2.55, cz + 0.22]
    mesh.add_cylinder(b6_start, b6_end, 0.032, 0.022, segments=5, mat_name="stem")
    mesh.add_leaf(b6_end, [cx + 0.65, y_soil + 2.75, cz + 0.35], [-0.2, 0.9, 0.3], 0.28, "leaf", fold=0.2)

    # Apex leaves at the top
    top_p = stem_pts[5]
    mesh.add_leaf(top_p, [cx + 0.08, y_soil + 3.42, cz + 0.18], [0, 0.9, 0.4], 0.26, "leaf_light", fold=0.2)
    mesh.add_leaf(top_p, [cx - 0.12, y_soil + 3.38, cz - 0.16], [-0.2, 0.9, -0.3], 0.24, "leaf_light", fold=0.2)
    mesh.add_leaf(top_p, [cx + 0.22, y_soil + 3.30, cz - 0.10], [0.3, 0.9, -0.2], 0.24, "leaf_light", fold=0.2)

    return mesh


def build_all_stages_scene():
    # ALL THREE STAGES on a greenhouse wooden bench (как на картинке пользователя!)
    mesh = Mesh("tomato_all_stages_scene")
    init_materials(mesh)
    
    # Left: Stage 1 (Sprout) at X = -2.3
    # Center: Stage 2 (Flowering) at X = 0.0
    # Right: Stage 3 (Mature with ripe tomatoes) at X = +2.3
    st1 = build_stage1(center=(-2.3, 0.0, 0.0))
    st2 = build_stage2(center=(0.0, 0.0, 0.0))
    st3 = build_stage3(center=(2.3, 0.0, 0.0))
    
    # Wooden Bench / Greenhouse Shelf (as in reference image)
    # Bench top plank: from X = -3.8 to +3.8, Y = -0.35 to 0.0, Z = -1.3 to +1.3
    # Front beveled board
    bx1, bx2 = -3.8, 3.8
    by1, by2 = -0.32, 0.0
    bz1, bz2 = -1.2, 1.2
    
    # Top face
    mesh.add_quad([bx1, by2, bz1], [bx2, by2, bz1], [bx2, by2, bz2], [bx1, by2, bz2], "bench_wood")
    # Front face
    mesh.add_quad([bx1, by1, bz2], [bx2, by1, bz2], [bx2, by2, bz2], [bx1, by2, bz2], "bench_wood")
    # Back face
    mesh.add_quad([bx2, by1, bz1], [bx1, by1, bz1], [bx1, by2, bz1], [bx2, by2, bz1], "bench_wood")
    # Left end
    mesh.add_quad([bx1, by1, bz1], [bx1, by1, bz2], [bx1, by2, bz2], [bx1, by2, bz1], "bench_wood")
    # Right end
    mesh.add_quad([bx2, by1, bz2], [bx2, by1, bz1], [bx2, by2, bz1], [bx2, by2, bz2], "bench_wood")

    # Combine sub-meshes into one
    for sub in [st1, st2, st3]:
        offset = len(mesh.vertices)
        mesh.vertices.extend(sub.vertices)
        mesh.normals.extend(sub.normals)
        mesh.colors.extend(sub.colors)
        for mat_name, faces in sub.material_faces.items():
            if mat_name not in mesh.material_faces:
                mesh.material_faces[mat_name] = []
            for f1, f2, f3 in faces:
                mesh.material_faces[mat_name].append((f1 + offset, f2 + offset, f3 + offset))

    return mesh, st1, st2, st3


def main():
    out_dir = r"C:\Users\user\.gemini\antigravity\scratch\tomato-3d-stages"
    os.makedirs(out_dir, exist_ok=True)
    
    print("Generating Tomato 3D models for all 3 stages...")
    
    # Individual models centered at origin (0, 0, 0) for clean asset importing
    st1 = build_stage1(center=(0.0, 0.0, 0.0))
    st2 = build_stage2(center=(0.0, 0.0, 0.0))
    st3 = build_stage3(center=(0.0, 0.0, 0.0))
    
    # Combined scene with greenhouse bench and all 3 stages side-by-side
    scene, _, _, _ = build_all_stages_scene()
    
    models = [
        ("stage1_sprout", st1),
        ("stage2_flowering", st2),
        ("stage3_mature", st3),
        ("all_stages_scene", scene)
    ]
    
    json_data = {}
    
    for name, m in models:
        obj_file = os.path.join(out_dir, f"{name}.obj")
        mtl_file = os.path.join(out_dir, f"{name}.mtl")
        gltf_file = os.path.join(out_dir, f"{name}.gltf")
        glb_file = os.path.join(out_dir, f"{name}.glb")
        
        m.export_obj(obj_file, f"{name}.mtl")
        m.export_mtl(mtl_file)
        m.export_gltf(gltf_file)
        m.export_glb(glb_file)
        
        print(f"Generated: {name}.glb & {name}.obj ({len(m.vertices)} vertices, {sum(len(f) for f in m.material_faces.values())} triangles)")
        json_data[name] = m.to_compact_dict()
        
    # Save combined JSON data for WebGL visualizer
    json_path = os.path.join(out_dir, "models_data.json")
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(json_data, f)
        
    print(f"All files exported successfully to {out_dir}")

if __name__ == "__main__":
    main()
