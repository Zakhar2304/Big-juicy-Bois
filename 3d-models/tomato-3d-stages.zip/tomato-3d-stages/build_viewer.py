import json
import os

def create_viewer_html():
    json_path = r"C:\Users\user\.gemini\antigravity\scratch\tomato-3d-stages\models_data.json"
    with open(json_path, "r", encoding="utf-8") as f:
        models_data = json.load(f)

    models_js = json.dumps(models_data)

    template = """<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <title>3D Модель Помидора: 3 Этапа Взросления</title>
  <script src="https://www.gstatic.com/antigravity/web/dev/tailwindcss.min.js"></script>
  <style>
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
      user-select: none;
      -webkit-user-select: none;
    }
    .stage-pill.active {
      background-color: #e07a5f;
      color: white;
      border-color: transparent;
      box-shadow: 0 2px 8px rgba(224, 122, 95, 0.35);
    }
  </style>
</head>
<body class="bg-transparent text-[var(--foreground)] antialiased p-0 m-0">
  <div class="max-w-4xl mx-auto p-2 sm:p-4 space-y-3">
    <!-- Header -->
    <div class="flex flex-wrap items-center justify-between gap-2 border-b border-[var(--card-border,#e5e7eb)] pb-2.5">
      <div>
        <div class="flex items-center gap-2">
          <span class="text-xl">🪴</span>
          <h2 class="text-base sm:text-lg font-bold text-[var(--foreground)]">3D Модель Помидора: 3 Этапа Роста</h2>
          <span class="text-xs px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-600 font-medium border border-emerald-500/20">Low-Poly 3D</span>
        </div>
        <p class="text-xs text-[var(--muted-foreground,#6b7280)] mt-0.5">
          Стилизованная модель в милом глиняном горшочке с личиком • OBJ / MTL / glTF
        </p>
      </div>
      
      <!-- Stage Switcher Tabs -->
      <div class="flex items-center gap-1 bg-[var(--card,#f3f4f6)] p-1 rounded-xl border border-[var(--card-border,#e5e7eb)] text-xs font-medium">
        <button id="btn-st1" onclick="setStage('stage1_sprout')" class="stage-pill px-3 py-1.5 rounded-lg border border-transparent transition-all">
          🌱 Росток
        </button>
        <button id="btn-st2" onclick="setStage('stage2_flowering')" class="stage-pill px-3 py-1.5 rounded-lg border border-transparent transition-all">
          🌿 Цветение
        </button>
        <button id="btn-st3" onclick="setStage('stage3_mature')" class="stage-pill active px-3 py-1.5 rounded-lg border border-transparent transition-all">
          🍅 Урожай
        </button>
        <button id="btn-all" onclick="setStage('all_stages_scene')" class="stage-pill px-3 py-1.5 rounded-lg border border-transparent transition-all">
          🪵 Все вместе
        </button>
      </div>
    </div>

    <!-- 3D Canvas Viewport -->
    <div class="relative w-full rounded-2xl overflow-hidden border border-[var(--card-border,#e5e7eb)] bg-gradient-to-b from-[#f8fafc] to-[#e2e8f0] dark:from-[#1e293b] dark:to-[#0f172a] shadow-inner" style="height: 380px;">
      <canvas id="glcanvas" class="w-full h-full cursor-grab active:cursor-grabbing block"></canvas>

      <!-- Viewport Overlay Controls -->
      <div class="absolute top-3 left-3 flex flex-col gap-1.5 z-10 pointer-events-none">
        <div id="stage-badge" class="px-2.5 py-1 rounded-lg bg-black/60 backdrop-blur-md text-white text-xs font-semibold flex items-center gap-1.5 shadow">
          <span>🍅</span> <span id="stage-title">Этап 3: Спелый урожай</span>
        </div>
        <div class="text-[10px] text-white/80 bg-black/40 backdrop-blur-sm px-2 py-0.5 rounded-md inline-block w-fit">
          🖱️ ЛКМ: вращение • Колесо: зум • ПКМ: панорама
        </div>
      </div>

      <div class="absolute top-3 right-3 flex items-center gap-1.5 z-10">
        <button id="btn-autorotate" onclick="toggleAutoRotate()" class="px-2.5 py-1 rounded-lg bg-white/90 dark:bg-slate-800/90 text-[var(--foreground)] hover:bg-white text-xs border border-black/10 dark:border-white/10 shadow-sm flex items-center gap-1">
          <span id="spin-icon">🔄</span> <span id="spin-label">Автоповорот</span>
        </button>
        <button onclick="resetCamera()" class="p-1.5 rounded-lg bg-white/90 dark:bg-slate-800/90 text-[var(--foreground)] hover:bg-white text-xs border border-black/10 dark:border-white/10 shadow-sm" title="Сбросить камеру">
          🎯
        </button>
      </div>

      <!-- Stage Growth Slider / Fast Switcher -->
      <div class="absolute bottom-3 left-1/2 -translate-x-1/2 bg-white/95 dark:bg-slate-800/95 backdrop-blur-md px-3 py-1.5 rounded-full border border-black/10 dark:border-white/10 shadow-lg flex items-center gap-3 z-10">
        <span class="text-[11px] font-medium text-[var(--muted-foreground)]">Стадия роста:</span>
        <input id="growth-slider" type="range" min="1" max="4" value="3" step="1" oninput="onSliderChange(this.value)" class="w-32 accent-[#e07a5f] cursor-pointer">
        <span id="slider-label" class="text-xs font-bold text-[#e07a5f] min-w-[70px] text-center">3: Урожай</span>
      </div>
    </div>

    <!-- Details Card & Actions -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-3">
      <!-- Description of current stage -->
      <div class="md:col-span-2 p-3 rounded-xl bg-[var(--card,#f9fafb)] border border-[var(--card-border,#e5e7eb)] text-xs space-y-1.5">
        <div class="flex items-center justify-between">
          <h3 id="desc-title" class="font-bold text-sm text-[var(--foreground)]">Этап 3: Взрослый куст со спелыми помидорами</h3>
          <span id="poly-count" class="text-[10px] text-[var(--muted-foreground)] font-mono">1 162 полигонов</span>
        </div>
        <p id="desc-text" class="text-[var(--muted-foreground)] leading-relaxed">
          Пышный плодоносящий куст с деревянным колышком и подвязками. 3 крупных спелых ярко-красных помидора с резными пятиконечными чашелистиками (в точности как на вашем референсе), 1 зелёный помидорчик и цветущие бутоны на макушке.
        </p>
        <div id="features-tags" class="flex flex-wrap gap-1.5 pt-1">
          <span class="px-2 py-0.5 rounded bg-red-500/10 text-red-600 font-medium">3 спелых плода</span>
          <span class="px-2 py-0.5 rounded bg-amber-500/10 text-amber-700 font-medium">Подвязка к колышку</span>
          <span class="px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-700 font-medium">Сложные листья</span>
          <span class="px-2 py-0.5 rounded bg-orange-500/10 text-orange-700 font-medium">Горшок с личиком</span>
        </div>
      </div>

      <!-- Local File Reference & OBJ Export -->
      <div class="p-3 rounded-xl bg-[var(--card,#f9fafb)] border border-[var(--card-border,#e5e7eb)] text-xs flex flex-col justify-between gap-2">
        <div>
          <h4 class="font-bold text-[var(--foreground)] mb-1">Готовые 3D файлы:</h4>
          <p class="text-[11px] text-[var(--muted-foreground)]">Сохранены на вашем диске в форматах OBJ и glTF для импорта в Blender / Unity / Godot:</p>
        </div>
        <div class="space-y-1.5">
          <button onclick="downloadCurrentObj()" class="w-full py-1.5 px-3 rounded-lg bg-[#e07a5f] hover:bg-[#d66a48] text-white font-medium flex items-center justify-center gap-1.5 shadow-sm transition-colors">
            <span>💾</span> <span>Скачать текущий .OBJ</span>
          </button>
          <div class="text-[10px] text-center text-[var(--muted-foreground)]">
            Файлы: <span class="font-mono font-semibold">stage1 / stage2 / stage3 / all_stages</span>
          </div>
        </div>
      </div>
    </div>
  </div>

  <script>
    const modelsData = __MODELS_JSON__;
    
    const STAGE_META = {
      stage1_sprout: {
        title: "Этап 1: Сеянец (Росток)",
        icon: "🌱",
        poly: "350 полигонов",
        desc: "Первые листочки помидора: тонкий нежный стебелёк, пара широких семядольных листьев и две крохотные пробивающиеся настоящие листовые пластинки. Посажен в уютный глиняный горшочек с глазками и улыбкой.",
        tags: ["Семядоли", "Нежный росток", "Компактный", "Низкополигональный"],
        camDist: 4.8,
        camTarget: [0, 1.8, 0],
        sliderVal: 1
      },
      stage2_flowering: {
        title: "Этап 2: Подросший куст (Цветение)",
        icon: "🌿",
        poly: "614 полигонов",
        desc: "Куст окреп и пошёл в активный рост. Появился деревянный бамбуковый колышек с джутовыми подвязками. Сформированы боковые побеги со сложными резными листьями, ярко-жёлтые цветки и первая зелёная завязь помидорчика.",
        tags: ["Жёлтые цветки", "Зелёная завязь", "Бамбуковый колышек", "Ветвление"],
        camDist: 5.6,
        camTarget: [0, 2.2, 0],
        sliderVal: 2
      },
      stage3_mature: {
        title: "Этап 3: Взрослый куст со спелыми помидорами",
        icon: "🍅",
        poly: "1 162 полигонов",
        desc: "Пышный плодоносящий куст, в точности передающий растение из референса! 3 сочных глянцевых красных помидора с характерными резными 5-конечными чашелистиками, 1 созревающий плод, верхушечные побеги и колышек.",
        tags: ["3 красных плода", "Резные чашелистики", "Подвязка", "Горшок с улыбкой"],
        camDist: 6.8,
        camTarget: [0, 2.6, 0],
        sliderVal: 3
      },
      all_stages_scene: {
        title: "Все 3 этапа вместе на полке оранжереи",
        icon: "🪵",
        poly: "2 136 полигонов",
        desc: "Полная эволюция помидора в ряд на деревянной дощатой полке, как в солнечной оранжерее на референсном изображении: от крохотного ростка слева до сочного плодоносящего куста справа.",
        tags: ["Вся композиция", "Деревянная полка", "3 горшочка", "Сравнение масштабов"],
        camDist: 9.2,
        camTarget: [0, 1.8, 0],
        sliderVal: 4
      }
    };

    let currentStage = 'stage3_mature';
    let autoRotate = true;
    let yaw = 0.45;
    let pitch = 0.22;
    let distance = 6.8;
    let target = [0, 2.6, 0];
    let isDragging = false;
    let lastMouseX = 0;
    let lastMouseY = 0;
    let isPanning = false;

    // WebGL Context and Resources
    let gl = null;
    let program = null;
    let buffers = {};
    let currentBuffers = null;
    let uProjection, uView, uModel, uLightDir, uCameraPos;

    function initWebGL() {
      const canvas = document.getElementById('glcanvas');
      gl = canvas.getContext('webgl', { antialias: true, alpha: false });
      if (!gl) {
        console.error("WebGL not supported");
        return;
      }

      function resize() {
        const dpr = window.devicePixelRatio || 1;
        const width = Math.floor(canvas.clientWidth * dpr);
        const height = Math.floor(canvas.clientHeight * dpr);
        if (canvas.width !== width || canvas.height !== height) {
          canvas.width = width;
          canvas.height = height;
          gl.viewport(0, 0, width, height);
        }
      }
      window.addEventListener('resize', resize);
      resize();

      const vsSource = `
        attribute vec3 aPosition;
        attribute vec3 aNormal;
        attribute vec3 aColor;

        uniform mat4 uProjection;
        uniform mat4 uView;
        uniform mat4 uModel;

        varying vec3 vNormal;
        varying vec3 vPosition;
        varying vec3 vColor;

        void main() {
          vec4 worldPos = uModel * vec4(aPosition, 1.0);
          vPosition = worldPos.xyz;
          vNormal = mat3(uModel) * aNormal;
          vColor = aColor;
          gl_Position = uProjection * uView * worldPos;
        }
      `;

      const fsSource = `
        precision mediump float;

        varying vec3 vNormal;
        varying vec3 vPosition;
        varying vec3 vColor;

        uniform vec3 uLightDir;
        uniform vec3 uCameraPos;

        void main() {
          vec3 N = normalize(vNormal);
          vec3 L = normalize(uLightDir);
          vec3 V = normalize(uCameraPos - vPosition);
          vec3 H = normalize(L + V);

          float diff = max(dot(N, L), 0.0);
          float fill = max(dot(N, vec3(-0.4, 0.7, -0.4)), 0.0) * 0.35;
          float bounce = max(dot(N, vec3(0.0, -1.0, 0.0)), 0.0) * 0.15;
          vec3 ambient = vec3(0.38, 0.40, 0.44);

          float spec = pow(max(dot(N, H), 0.0), 32.0) * 0.38;

          vec3 light = ambient + vec3(1.0, 0.96, 0.88) * diff + vec3(0.6, 0.7, 0.85) * fill + vec3(0.35, 0.25, 0.2) * bounce;
          vec3 color = vColor * light + vec3(spec);

          gl_FragColor = vec4(color, 1.0);
        }
      `;

      program = createProgram(gl, vsSource, fsSource);
      gl.useProgram(program);

      uProjection = gl.getUniformLocation(program, 'uProjection');
      uView = gl.getUniformLocation(program, 'uView');
      uModel = gl.getUniformLocation(program, 'uModel');
      uLightDir = gl.getUniformLocation(program, 'uLightDir');
      uCameraPos = gl.getUniformLocation(program, 'uCameraPos');

      for (const [key, data] of Object.entries(modelsData)) {
        const vPosBuf = gl.createBuffer();
        gl.bindBuffer(gl.ARRAY_BUFFER, vPosBuf);
        gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(data.vertices), gl.STATIC_DRAW);

        const vNormBuf = gl.createBuffer();
        gl.bindBuffer(gl.ARRAY_BUFFER, vNormBuf);
        gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(data.normals), gl.STATIC_DRAW);

        const vColBuf = gl.createBuffer();
        gl.bindBuffer(gl.ARRAY_BUFFER, vColBuf);
        gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(data.colors), gl.STATIC_DRAW);

        const idxBuf = gl.createBuffer();
        gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, idxBuf);
        gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint16Array(data.indices), gl.STATIC_DRAW);

        buffers[key] = {
          pos: vPosBuf,
          norm: vNormBuf,
          col: vColBuf,
          idx: idxBuf,
          count: data.indices.length
        };
      }

      currentBuffers = buffers[currentStage];
      gl.enable(gl.DEPTH_TEST);
      gl.depthFunc(gl.LEQUAL);
      gl.clearColor(0.93, 0.95, 0.96, 1.0);

      setupEvents(canvas);
      requestAnimationFrame(render);
    }

    function createProgram(gl, vsSrc, fsSrc) {
      function compile(type, src) {
        const s = gl.createShader(type);
        gl.shaderSource(s, src);
        gl.compileShader(s);
        if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) {
          console.error(gl.getShaderInfoLog(s));
          gl.deleteShader(s);
          return null;
        }
        return s;
      }
      const vs = compile(gl.VERTEX_SHADER, vsSrc);
      const fs = compile(gl.FRAGMENT_SHADER, fsSrc);
      const p = gl.createProgram();
      gl.attachShader(p, vs);
      gl.attachShader(p, fs);
      gl.linkProgram(p);
      return p;
    }

    function setupEvents(canvas) {
      canvas.addEventListener('mousedown', (e) => {
        isDragging = true;
        isPanning = (e.button === 2 || e.button === 1);
        lastMouseX = e.clientX;
        lastMouseY = e.clientY;
      });
      window.addEventListener('mouseup', () => {
        isDragging = false;
        isPanning = false;
      });
      canvas.addEventListener('contextmenu', (e) => e.preventDefault());

      window.addEventListener('mousemove', (e) => {
        if (!isDragging) return;
        const dx = e.clientX - lastMouseX;
        const dy = e.clientY - lastMouseY;
        lastMouseX = e.clientX;
        lastMouseY = e.clientY;

        if (isPanning) {
          const factor = distance * 0.0018;
          target[0] -= dx * factor * Math.cos(yaw) + dy * factor * Math.sin(yaw) * Math.sin(pitch);
          target[1] += dy * factor * Math.cos(pitch);
          target[2] -= dx * factor * Math.sin(yaw);
        } else {
          yaw -= dx * 0.008;
          pitch = Math.max(-1.1, Math.min(1.2, pitch + dy * 0.008));
          autoRotate = false;
          updateAutoRotateBtn();
        }
      });

      canvas.addEventListener('wheel', (e) => {
        e.preventDefault();
        distance = Math.max(2.5, Math.min(18.0, distance + e.deltaY * 0.006));
      }, { passive: false });

      let touchStartX = 0, touchStartY = 0, touchStartDist = 0;
      canvas.addEventListener('touchstart', (e) => {
        if (e.touches.length === 1) {
          isDragging = true;
          touchStartX = e.touches[0].clientX;
          touchStartY = e.touches[0].clientY;
        } else if (e.touches.length === 2) {
          touchStartDist = Math.hypot(
            e.touches[0].clientX - e.touches[1].clientX,
            e.touches[0].clientY - e.touches[1].clientY
          );
        }
      });
      canvas.addEventListener('touchmove', (e) => {
        if (e.touches.length === 1 && isDragging) {
          const dx = e.touches[0].clientX - touchStartX;
          const dy = e.touches[0].clientY - touchStartY;
          touchStartX = e.touches[0].clientX;
          touchStartY = e.touches[0].clientY;
          yaw -= dx * 0.01;
          pitch = Math.max(-1.1, Math.min(1.2, pitch + dy * 0.01));
          autoRotate = false;
          updateAutoRotateBtn();
        } else if (e.touches.length === 2) {
          const dist = Math.hypot(
            e.touches[0].clientX - e.touches[1].clientX,
            e.touches[0].clientY - e.touches[1].clientY
          );
          distance = Math.max(2.5, Math.min(18.0, distance - (dist - touchStartDist) * 0.02));
          touchStartDist = dist;
        }
      });
      canvas.addEventListener('touchend', () => { isDragging = false; });
    }

    function setStage(stageKey) {
      currentStage = stageKey;
      currentBuffers = buffers[stageKey];
      const meta = STAGE_META[stageKey];
      
      document.querySelectorAll('.stage-pill').forEach(btn => btn.classList.remove('active'));
      const activeBtnMap = {
        stage1_sprout: 'btn-st1',
        stage2_flowering: 'btn-st2',
        stage3_mature: 'btn-st3',
        all_stages_scene: 'btn-all'
      };
      document.getElementById(activeBtnMap[stageKey]).classList.add('active');

      document.getElementById('stage-badge').innerHTML = `<span>${meta.icon}</span> <span>${meta.title}</span>`;
      document.getElementById('desc-title').innerText = meta.title;
      document.getElementById('poly-count').innerText = meta.poly;
      document.getElementById('desc-text').innerText = meta.desc;
      
      const tagsContainer = document.getElementById('features-tags');
      tagsContainer.innerHTML = meta.tags.map(t => `<span class="px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-700 font-medium">${t}</span>`).join('');

      document.getElementById('growth-slider').value = meta.sliderVal;
      document.getElementById('slider-label').innerText = `${meta.sliderVal}: ${meta.title.split(':')[0]}`;

      target = [...meta.camTarget];
      distance = meta.camDist;
    }

    function onSliderChange(val) {
      const map = { '1': 'stage1_sprout', '2': 'stage2_flowering', '3': 'stage3_mature', '4': 'all_stages_scene' };
      setStage(map[val]);
    }

    function toggleAutoRotate() {
      autoRotate = !autoRotate;
      updateAutoRotateBtn();
    }

    function updateAutoRotateBtn() {
      const btn = document.getElementById('btn-autorotate');
      if (autoRotate) {
        btn.classList.add('bg-emerald-500/10', 'text-emerald-700', 'border-emerald-500/30');
        document.getElementById('spin-label').innerText = 'Вращается';
      } else {
        btn.classList.remove('bg-emerald-500/10', 'text-emerald-700', 'border-emerald-500/30');
        document.getElementById('spin-label').innerText = 'Автоповорот';
      }
    }

    function resetCamera() {
      const meta = STAGE_META[currentStage];
      yaw = 0.45;
      pitch = 0.22;
      distance = meta.camDist;
      target = [...meta.camTarget];
      autoRotate = true;
      updateAutoRotateBtn();
    }

    function mat4Perspective(out, fovy, aspect, near, far) {
      const f = 1.0 / Math.tan(fovy / 2);
      const nf = 1 / (near - far);
      out[0] = f / aspect; out[1] = 0; out[2] = 0; out[3] = 0;
      out[4] = 0; out[5] = f; out[6] = 0; out[7] = 0;
      out[8] = 0; out[9] = 0; out[10] = (far + near) * nf; out[11] = -1;
      out[12] = 0; out[13] = 0; out[14] = 2 * far * near * nf; out[15] = 0;
    }

    function mat4LookAt(out, eye, center, up) {
      let z0 = eye[0] - center[0], z1 = eye[1] - center[1], z2 = eye[2] - center[2];
      let len = 1 / Math.hypot(z0, z1, z2);
      z0 *= len; z1 *= len; z2 *= len;

      let x0 = up[1] * z2 - up[2] * z1, x1 = up[2] * z0 - up[0] * z2, x2 = up[0] * z1 - up[1] * z0;
      len = 1 / Math.hypot(x0, x1, x2);
      x0 *= len; x1 *= len; x2 *= len;

      let y0 = z1 * x2 - z2 * x1, y1 = z2 * x0 - z0 * x2, y2 = z0 * x1 - z1 * x0;

      out[0] = x0; out[1] = y0; out[2] = z0; out[3] = 0;
      out[4] = x1; out[5] = y1; out[6] = z1; out[7] = 0;
      out[8] = x2; out[9] = y2; out[10] = z2; out[11] = 0;
      out[12] = -(x0 * eye[0] + x1 * eye[1] + x2 * eye[2]);
      out[13] = -(y0 * eye[0] + y1 * eye[1] + y2 * eye[2]);
      out[14] = -(z0 * eye[0] + z1 * eye[1] + z2 * eye[2]);
      out[15] = 1;
    }

    function mat4Identity(out) {
      for (let i = 0; i < 16; i++) out[i] = (i % 5 === 0) ? 1 : 0;
    }

    const projMat = new Float32Array(16);
    const viewMat = new Float32Array(16);
    const modelMat = new Float32Array(16);

    function render() {
      if (autoRotate) {
        yaw += 0.007;
      }

      const eyeX = target[0] + distance * Math.cos(pitch) * Math.sin(yaw);
      const eyeY = target[1] + distance * Math.sin(pitch);
      const eyeZ = target[2] + distance * Math.cos(pitch) * Math.cos(yaw);

      const aspect = gl.canvas.width / gl.canvas.height;
      mat4Perspective(projMat, Math.PI / 4, aspect, 0.1, 100.0);
      mat4LookAt(viewMat, [eyeX, eyeY, eyeZ], target, [0, 1, 0]);
      mat4Identity(modelMat);

      gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

      if (currentBuffers) {
        gl.useProgram(program);

        gl.uniformMatrix4fv(uProjection, false, projMat);
        gl.uniformMatrix4fv(uView, false, viewMat);
        gl.uniformMatrix4fv(uModel, false, modelMat);
        gl.uniform3f(uLightDir, 0.6, 1.0, 0.5);
        gl.uniform3f(uCameraPos, eyeX, eyeY, eyeZ);

        const aPos = gl.getAttribLocation(program, 'aPosition');
        gl.enableVertexAttribArray(aPos);
        gl.bindBuffer(gl.ARRAY_BUFFER, currentBuffers.pos);
        gl.vertexAttribPointer(aPos, 3, gl.FLOAT, false, 0, 0);

        const aNorm = gl.getAttribLocation(program, 'aNormal');
        gl.enableVertexAttribArray(aNorm);
        gl.bindBuffer(gl.ARRAY_BUFFER, currentBuffers.norm);
        gl.vertexAttribPointer(aNorm, 3, gl.FLOAT, false, 0, 0);

        const aCol = gl.getAttribLocation(program, 'aColor');
        gl.enableVertexAttribArray(aCol);
        gl.bindBuffer(gl.ARRAY_BUFFER, currentBuffers.col);
        gl.vertexAttribPointer(aCol, 3, gl.FLOAT, false, 0, 0);

        gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, currentBuffers.idx);
        gl.drawElements(gl.TRIANGLES, currentBuffers.count, gl.UNSIGNED_SHORT, 0);
      }

      requestAnimationFrame(render);
    }

    function triggerDownload(filename, content, mime) {
      const blob = new Blob([content], { type: mime });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }

    function downloadCurrentObj() {
      const data = modelsData[currentStage];
      let objText = "# Wavefront OBJ generated by Tomato3D\\nmtllib " + currentStage + ".mtl\\n\\n";
      for (let i = 0; i < data.vertices.length; i += 3) {
        objText += "v " + data.vertices[i] + " " + data.vertices[i+1] + " " + data.vertices[i+2] + "\\n";
      }
      for (let i = 0; i < data.normals.length; i += 3) {
        objText += "vn " + data.normals[i] + " " + data.normals[i+1] + " " + data.normals[i+2] + "\\n";
      }
      objText += "\\ns 1\\n";
      for (let i = 0; i < data.indices.length; i += 3) {
        const i1 = data.indices[i] + 1;
        const i2 = data.indices[i+1] + 1;
        const i3 = data.indices[i+2] + 1;
        objText += "f " + i1 + "//" + i1 + " " + i2 + "//" + i2 + " " + i3 + "//" + i3 + "\\n";
      }
      triggerDownload(currentStage + ".obj", objText, 'text/plain');
    }

    window.onload = initWebGL;
  </script>
</body>
</html>
"""
    return template.replace("__MODELS_JSON__", models_js)

if __name__ == "__main__":
    html = create_viewer_html()
    out_path = r"C:\Users\user\.gemini\antigravity\scratch\tomato-3d-stages\tomato_3d_viewer.html"
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(html)
    print("Viewer HTML generated successfully at", out_path)
