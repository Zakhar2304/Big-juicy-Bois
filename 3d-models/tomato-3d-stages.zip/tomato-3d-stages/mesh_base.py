"""
Procedural 3D Mesh Generator for Low-Poly Tomato Plant (3 Stages of Growth)
Aesthetic matching stylized greenhouse potted plants with cute faces.
Exports:
- Wavefront OBJ + MTL
- glTF 2.0 (.gltf self-contained JSON with base64 buffers)
- JSON geometry for custom WebGL interactive viewer
"""

import math
import json
import base64
import struct
import os

class Mesh:
    def __init__(self, name="model"):
        self.name = name
        self.vertices = []  # list of [x, y, z]
        self.normals = []   # list of [nx, ny, nz]
        self.colors = []    # list of [r, g, b]
        # materials dictionary: mat_name -> list of triangle tuples of indices
        self.material_faces = {}
        self.materials = {} # mat_name -> { 'diffuse': [r, g, b], 'roughness': float, ... }

    def register_material(self, name, diffuse, roughness=0.6, specular=[0.1, 0.1, 0.1]):
        self.materials[name] = {
            'diffuse': diffuse,
            'roughness': roughness,
            'specular': specular
        }
        if name not in self.material_faces:
            self.material_faces[name] = []

    def add_triangle(self, p1, p2, p3, mat_name, normal=None):
        if mat_name not in self.material_faces:
            self.material_faces[mat_name] = []
            
        # compute flat normal if not provided
        if normal is None:
            ux, uy, uz = p2[0] - p1[0], p2[1] - p1[1], p2[2] - p1[2]
            vx, vy, vz = p3[0] - p1[0], p3[1] - p1[1], p3[2] - p1[2]
            nx = uy * vz - uz * vy
            ny = uz * vx - ux * vz
            nz = ux * vy - uy * vx
            l = math.sqrt(nx*nx + ny*ny + nz*nz)
            if l > 1e-7:
                normal = [nx/l, ny/l, nz/l]
            else:
                normal = [0.0, 1.0, 0.0]

        color = self.materials.get(mat_name, {}).get('diffuse', [0.8, 0.8, 0.8])
        idx = len(self.vertices)
        
        self.vertices.extend([p1, p2, p3])
        self.normals.extend([normal, normal, normal])
        self.colors.extend([color, color, color])
        self.material_faces[mat_name].append((idx, idx + 1, idx + 2))

    def add_quad(self, p1, p2, p3, p4, mat_name):
        # Two triangles: (p1, p2, p3) and (p1, p3, p4)
        self.add_triangle(p1, p2, p3, mat_name)
        self.add_triangle(p1, p3, p4, mat_name)

    def add_cylinder(self, p_bottom, p_top, r_bottom, r_top, segments=10, mat_name="pot"):
        # Cylinder/cone with circular or faceted cross section
        dx = p_top[0] - p_bottom[0]
        dy = p_top[1] - p_bottom[1]
        dz = p_top[2] - p_bottom[2]
        length = math.sqrt(dx*dx + dy*dy + dz*dz)
        if length < 1e-6:
            return

        # Basis vectors
        dir_v = [dx/length, dy/length, dz/length]
        up = [0, 1, 0] if abs(dir_v[1]) < 0.99 else [1, 0, 0]
        # side = dir x up
        side_x = dir_v[1]*up[2] - dir_v[2]*up[1]
        side_y = dir_v[2]*up[0] - dir_v[0]*up[2]
        side_z = dir_v[0]*up[1] - dir_v[1]*up[0]
        sl = math.sqrt(side_x*side_x + side_y*side_y + side_z*side_z)
        side = [side_x/sl, side_y/sl, side_z/sl]
        # up2 = side x dir
        up2 = [
            side[1]*dir_v[2] - side[2]*dir_v[1],
            side[2]*dir_v[0] - side[0]*dir_v[2],
            side[0]*dir_v[1] - side[1]*dir_v[0]
        ]

        bot_ring = []
        top_ring = []
        for i in range(segments):
            angle = 2.0 * math.pi * i / segments
            ca = math.cos(angle)
            sa = math.sin(angle)
            vx = side[0] * ca + up2[0] * sa
            vy = side[1] * ca + up2[1] * sa
            vz = side[2] * ca + up2[2] * sa

            p_bot = [
                p_bottom[0] + vx * r_bottom,
                p_bottom[1] + vy * r_bottom,
                p_bottom[2] + vz * r_bottom
            ]
            p_tp = [
                p_top[0] + vx * r_top,
                p_top[1] + vy * r_top,
                p_top[2] + vz * r_top
            ]
            bot_ring.append(p_bot)
            top_ring.append(p_tp)

        for i in range(segments):
            next_i = (i + 1) % segments
            # CCW outward quad
            self.add_quad(bot_ring[i], top_ring[i], top_ring[next_i], bot_ring[next_i], mat_name)

    def add_disk(self, center, radius, normal, segments=10, mat_name="soil"):
        nl = math.sqrt(normal[0]**2 + normal[1]**2 + normal[2]**2)
        n = [normal[0]/nl, normal[1]/nl, normal[2]/nl]
        up = [0, 1, 0] if abs(n[1]) < 0.99 else [1, 0, 0]
        # side = n x up
        side = [
            n[1]*up[2] - n[2]*up[1],
            n[2]*up[0] - n[0]*up[2],
            n[0]*up[1] - n[1]*up[0]
        ]
        sl = math.sqrt(side[0]**2 + side[1]**2 + side[2]**2)
        side = [side[0]/sl, side[1]/sl, side[2]/sl]
        up2 = [
            side[1]*n[2] - side[2]*n[1],
            side[2]*n[0] - side[0]*n[2],
            side[0]*n[1] - side[1]*n[0]
        ]

        ring = []
        for i in range(segments):
            angle = 2.0 * math.pi * i / segments
            ca = math.cos(angle)
            sa = math.sin(angle)
            p = [
                center[0] + (side[0]*ca + up2[0]*sa) * radius,
                center[1] + (side[1]*ca + up2[1]*sa) * radius,
                center[2] + (side[2]*ca + up2[2]*sa) * radius
            ]
            ring.append(p)

        for i in range(segments):
            next_i = (i + 1) % segments
            # CCW outward triangle matching normal
            self.add_triangle(center, ring[next_i], ring[i], mat_name, normal=n)

    def add_sphere(self, center, r, lat_segs=8, lon_segs=10, mat_name="tomato", squash_y=0.9):
        # Slightly squashed sphere for realistic low-poly tomato shape
        grid = []
        for i in range(lat_segs + 1):
            theta = math.pi * i / lat_segs
            row = []
            for j in range(lon_segs):
                phi = 2.0 * math.pi * j / lon_segs
                y_factor = squash_y
                if i == 0 or i == lat_segs:
                    rad = 0
                else:
                    rad = r * math.sin(theta)
                
                x = center[0] + rad * math.cos(phi)
                y = center[1] + r * math.cos(theta) * y_factor
                z = center[2] + rad * math.sin(phi)
                row.append([x, y, z])
            grid.append(row)

        for i in range(lat_segs):
            for j in range(lon_segs):
                next_j = (j + 1) % lon_segs
                p1 = grid[i][j]
                p2 = grid[i][next_j]
                p3 = grid[i+1][next_j]
                p4 = grid[i+1][j]
                if i == 0:
                    self.add_triangle(p1, p3, p4, mat_name)
                elif i == lat_segs - 1:
                    self.add_triangle(p1, p4, p3, mat_name)
                else:
                    self.add_quad(p1, p4, p3, p2, mat_name)

    def add_leaf(self, base, tip, normal, width, mat_name="leaf", fold=0.15):
        # Faceted stylized leaf with a central crease
        # Vector from base to tip
        dx = tip[0] - base[0]
        dy = tip[1] - base[1]
        dz = tip[2] - base[2]
        length = math.sqrt(dx*dx + dy*dy + dz*dz)
        if length < 1e-6:
            return
        dir_v = [dx/length, dy/length, dz/length]

        # Perpendicular vector in leaf plane
        nl = math.sqrt(normal[0]**2 + normal[1]**2 + normal[2]**2)
        norm = [normal[0]/nl, normal[1]/nl, normal[2]/nl]
        
        # wing vector = norm x dir
        wing = [
            norm[1]*dir_v[2] - norm[2]*dir_v[1],
            norm[2]*dir_v[0] - norm[0]*dir_v[2],
            norm[0]*dir_v[1] - norm[1]*dir_v[0]
        ]
        wl = math.sqrt(wing[0]**2 + wing[1]**2 + wing[2]**2)
        if wl < 1e-6:
            wing = [1, 0, 0]
        else:
            wing = [wing[0]/wl, wing[1]/wl, wing[2]/wl]

        # mid point along stem
        mid_spine = [
            base[0] + dir_v[0] * length * 0.45 - norm[0] * fold * width,
            base[1] + dir_v[1] * length * 0.45 - norm[1] * fold * width,
            base[2] + dir_v[2] * length * 0.45 - norm[2] * fold * width
        ]

        # left & right outer points (tilted slightly up by fold)
        left_p = [
            mid_spine[0] + wing[0] * width * 0.5 + norm[0] * fold * width,
            mid_spine[1] + wing[1] * width * 0.5 + norm[1] * fold * width,
            mid_spine[2] + wing[2] * width * 0.5 + norm[2] * fold * width
        ]
        right_p = [
            mid_spine[0] - wing[0] * width * 0.5 + norm[0] * fold * width,
            mid_spine[1] - wing[1] * width * 0.5 + norm[1] * fold * width,
            mid_spine[2] - wing[2] * width * 0.5 + norm[2] * fold * width
        ]

        # 4 triangles creating a folded 3D low-poly leaf
        self.add_triangle(base, left_p, mid_spine, mat_name)
        self.add_triangle(base, mid_spine, right_p, mat_name)
        self.add_triangle(mid_spine, left_p, tip, mat_name)
        self.add_triangle(mid_spine, tip, right_p, mat_name)

    def add_star_calyx(self, center, stem_dir, radius=0.18, points=5, mat_name="calyx"):
        # 5-pointed star sepal on top of a tomato
        nl = math.sqrt(stem_dir[0]**2 + stem_dir[1]**2 + stem_dir[2]**2)
        n = [stem_dir[0]/nl, stem_dir[1]/nl, stem_dir[2]/nl]
        up = [0, 1, 0] if abs(n[1]) < 0.9 else [1, 0, 0]
        side = [
            n[1]*up[2] - n[2]*up[1],
            n[2]*up[0] - n[0]*up[2],
            n[0]*up[1] - n[1]*up[0]
        ]
        sl = math.sqrt(side[0]**2 + side[1]**2 + side[2]**2)
        side = [side[0]/sl, side[1]/sl, side[2]/sl]
        up2 = [
            side[1]*n[2] - side[2]*n[1],
            side[2]*n[0] - side[0]*n[2],
            side[0]*n[1] - side[1]*n[0]
        ]

        inner_r = radius * 0.35
        outer_r = radius

        tips = []
        inners = []
        for i in range(points):
            angle = 2.0 * math.pi * i / points
            # tip points slightly down curved over the tomato
            ca = math.cos(angle)
            sa = math.sin(angle)
            pt = [
                center[0] + (side[0]*ca + up2[0]*sa) * outer_r - n[0] * 0.05,
                center[1] + (side[1]*ca + up2[1]*sa) * outer_r - n[1] * 0.05,
                center[2] + (side[2]*ca + up2[2]*sa) * outer_r - n[2] * 0.05
            ]
            tips.append(pt)

            angle_in = angle + math.pi / points
            c_in = math.cos(angle_in)
            s_in = math.sin(angle_in)
            pt_in = [
                center[0] + (side[0]*c_in + up2[0]*s_in) * inner_r,
                center[1] + (side[1]*c_in + up2[1]*s_in) * inner_r,
                center[2] + (side[2]*c_in + up2[2]*s_in) * inner_r
            ]
            inners.append(pt_in)

        for i in range(points):
            prev_in = inners[(i - 1 + points) % points]
            curr_in = inners[i]
            tip = tips[i]
            self.add_triangle(center, prev_in, tip, mat_name)
            self.add_triangle(center, tip, curr_in, mat_name)

    def add_flower(self, center, dir_v, size=0.14):
        # 5 yellow petals and central pistil/cone
        nl = math.sqrt(dir_v[0]**2 + dir_v[1]**2 + dir_v[2]**2)
        n = [dir_v[0]/nl, dir_v[1]/nl, dir_v[2]/nl]
        up = [0, 1, 0] if abs(n[1]) < 0.9 else [1, 0, 0]
        side = [
            n[1]*up[2] - n[2]*up[1],
            n[2]*up[0] - n[0]*up[2],
            n[0]*up[1] - n[1]*up[0]
        ]
        sl = math.sqrt(side[0]**2 + side[1]**2 + side[2]**2)
        side = [side[0]/sl, side[1]/sl, side[2]/sl]
        up2 = [
            side[1]*n[2] - side[2]*n[1],
            side[2]*n[0] - side[0]*n[2],
            side[0]*n[1] - side[1]*n[0]
        ]

        # small green center cone
        apex = [center[0] + n[0] * 0.05, center[1] + n[1] * 0.05, center[2] + n[2] * 0.05]
        self.add_cylinder(center, apex, size*0.25, 0.01, segments=6, mat_name="flower_center")

        petals = 5
        for i in range(petals):
            a1 = 2.0 * math.pi * (i - 0.35) / petals
            a_tip = 2.0 * math.pi * i / petals
            a2 = 2.0 * math.pi * (i + 0.35) / petals
            
            p1 = [
                center[0] + (side[0]*math.cos(a1) + up2[0]*math.sin(a1)) * size * 0.3,
                center[1] + (side[1]*math.cos(a1) + up2[1]*math.sin(a1)) * size * 0.3,
                center[2] + (side[2]*math.cos(a1) + up2[2]*math.sin(a1)) * size * 0.3
            ]
            p_tip = [
                center[0] + (side[0]*math.cos(a_tip) + up2[0]*math.sin(a_tip)) * size + n[0]*0.02,
                center[1] + (side[1]*math.cos(a_tip) + up2[1]*math.sin(a_tip)) * size + n[1]*0.02,
                center[2] + (side[2]*math.cos(a_tip) + up2[2]*math.sin(a_tip)) * size + n[2]*0.02
            ]
            p2 = [
                center[0] + (side[0]*math.cos(a2) + up2[0]*math.sin(a2)) * size * 0.3,
                center[1] + (side[1]*math.cos(a2) + up2[1]*math.sin(a2)) * size * 0.3,
                center[2] + (side[2]*math.cos(a2) + up2[2]*math.sin(a2)) * size * 0.3
            ]
            self.add_triangle(center, p1, p_tip, "flower_petal")
            self.add_triangle(center, p_tip, p2, "flower_petal")

    def export_obj(self, filepath, mtl_name="materials.mtl"):
        with open(filepath, "w", encoding="utf-8") as f:
            f.write(f"# Wavefront OBJ exported by Tomato3D Generator\n")
            f.write(f"mtllib {mtl_name}\n\n")
            
            # Write vertices
            for v in self.vertices:
                f.write(f"v {v[0]:.4f} {v[1]:.4f} {v[2]:.4f}\n")
            
            # Write vertex normals
            for n in self.normals:
                f.write(f"vn {n[0]:.4f} {n[1]:.4f} {n[2]:.4f}\n")
                
            # Write faces grouped by material
            for mat_name, faces in self.material_faces.items():
                if not faces:
                    continue
                f.write(f"\nusemtl {mat_name}\n")
                f.write(f"s 1\n")
                for f1, f2, f3 in faces:
                    # 1-indexed in OBJ
                    f.write(f"f {f1+1}//{f1+1} {f2+1}//{f2+1} {f3+1}//{f3+1}\n")

    def export_mtl(self, filepath):
        with open(filepath, "w", encoding="utf-8") as f:
            f.write(f"# Wavefront MTL Material File\n\n")
            for mat_name, mat in self.materials.items():
                f.write(f"newmtl {mat_name}\n")
                diff = mat.get('diffuse', [0.8, 0.8, 0.8])
                spec = mat.get('specular', [0.1, 0.1, 0.1])
                f.write(f"Ka {diff[0]*0.2:.3f} {diff[1]*0.2:.3f} {diff[2]*0.2:.3f}\n")
                f.write(f"Kd {diff[0]:.3f} {diff[1]:.3f} {diff[2]:.3f}\n")
                f.write(f"Ks {spec[0]:.3f} {spec[1]:.3f} {spec[2]:.3f}\n")
                f.write(f"Ns 25.0\n")
                f.write(f"d 1.0\n")
                f.write(f"illum 2\n\n")

    def export_gltf(self, filepath):
        # Build self-contained glTF 2.0 JSON with base64 data URI buffer
        # Attributes: POSITION (float32 x 3), NORMAL (float32 x 3), COLOR_0 (float32 x 3)
        pos_bytes = bytearray()
        norm_bytes = bytearray()
        col_bytes = bytearray()
        index_bytes = bytearray()

        min_pos = [float('inf')]*3
        max_pos = [float('-inf')]*3

        for i, v in enumerate(self.vertices):
            for k in range(3):
                min_pos[k] = min(min_pos[k], v[k])
                max_pos[k] = max(max_pos[k], v[k])
            pos_bytes.extend(struct.pack('<fff', v[0], v[1], v[2]))
            n = self.normals[i]
            norm_bytes.extend(struct.pack('<fff', n[0], n[1], n[2]))
            c = self.colors[i]
            col_bytes.extend(struct.pack('<fff', c[0], c[1], c[2]))

        # We will create primitives per material
        primitives = []
        gltf_materials = []
        mat_map = {}

        # Concatenate indices for all materials
        buffer_bytes = bytearray()
        buffer_bytes.extend(pos_bytes)
        pos_offset = 0
        pos_length = len(pos_bytes)

        norm_offset = len(buffer_bytes)
        buffer_bytes.extend(norm_bytes)
        norm_length = len(norm_bytes)

        col_offset = len(buffer_bytes)
        buffer_bytes.extend(col_bytes)
        col_length = len(col_bytes)

        # Buffer views: 0: pos, 1: norm, 2: col, 3+: indices per primitive
        buffer_views = [
            {"buffer": 0, "byteOffset": pos_offset, "byteLength": pos_length, "target": 34962},
            {"buffer": 0, "byteOffset": norm_offset, "byteLength": norm_length, "target": 34962},
            {"buffer": 0, "byteOffset": col_offset, "byteLength": col_length, "target": 34962}
        ]

        accessors = [
            # 0: POSITION
            {
                "bufferView": 0,
                "byteOffset": 0,
                "componentType": 5126, # FLOAT
                "count": len(self.vertices),
                "type": "VEC3",
                "max": max_pos if self.vertices else [0,0,0],
                "min": min_pos if self.vertices else [0,0,0]
            },
            # 1: NORMAL
            {
                "bufferView": 1,
                "byteOffset": 0,
                "componentType": 5126,
                "count": len(self.normals),
                "type": "VEC3"
            },
            # 2: COLOR_0
            {
                "bufferView": 2,
                "byteOffset": 0,
                "componentType": 5126,
                "count": len(self.colors),
                "type": "VEC3"
            }
        ]

        for mat_name, faces in self.material_faces.items():
            if not faces:
                continue
            mat_idx = len(gltf_materials)
            diff = self.materials[mat_name]['diffuse']
            gltf_materials.append({
                "name": mat_name,
                "doubleSided": True,
                "pbrMetallicRoughness": {
                    "baseColorFactor": [diff[0], diff[1], diff[2], 1.0],
                    "metallicFactor": 0.05,
                    "roughnessFactor": 0.7
                }
            })

            # Pack indices (uint32)
            cur_idx_bytes = bytearray()
            min_idx = 999999999
            max_idx = 0
            for f in faces:
                for idx in f:
                    min_idx = min(min_idx, idx)
                    max_idx = max(max_idx, idx)
                    cur_idx_bytes.extend(struct.pack('<I', idx))

            idx_offset = len(buffer_bytes)
            buffer_bytes.extend(cur_idx_bytes)
            idx_view = len(buffer_views)
            buffer_views.append({
                "buffer": 0,
                "byteOffset": idx_offset,
                "byteLength": len(cur_idx_bytes),
                "target": 34963 # ELEMENT_ARRAY_BUFFER
            })
            idx_acc = len(accessors)
            accessors.append({
                "bufferView": idx_view,
                "byteOffset": 0,
                "componentType": 5125, # UNSIGNED_INT
                "count": len(faces) * 3,
                "type": "SCALAR",
                "max": [max_idx],
                "min": [min_idx]
            })

            primitives.append({
                "attributes": {
                    "POSITION": 0,
                    "NORMAL": 1,
                    "COLOR_0": 2
                },
                "indices": idx_acc,
                "material": mat_idx
            })

        b64_data = base64.b64encode(buffer_bytes).decode('ascii')
        gltf_dict = {
            "asset": {"version": "2.0", "generator": "Tomato3D_Generator"},
            "scenes": [{"nodes": [0]}],
            "scene": 0,
            "nodes": [{"mesh": 0, "name": self.name}],
            "meshes": [{"name": self.name, "primitives": primitives}],
            "materials": gltf_materials,
            "accessors": accessors,
            "bufferViews": buffer_views,
            "buffers": [{"uri": f"data:application/octet-stream;base64,{b64_data}", "byteLength": len(buffer_bytes)}]
        }

        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(gltf_dict, f, indent=2)

    def export_glb(self, filepath):
        # Build self-contained glTF 2.0 Binary (.glb) container
        pos_bytes = bytearray()
        norm_bytes = bytearray()
        col_bytes = bytearray()

        min_pos = [float('inf')]*3
        max_pos = [float('-inf')]*3

        for i, v in enumerate(self.vertices):
            for k in range(3):
                min_pos[k] = min(min_pos[k], v[k])
                max_pos[k] = max(max_pos[k], v[k])
            pos_bytes.extend(struct.pack('<fff', v[0], v[1], v[2]))
            n = self.normals[i]
            norm_bytes.extend(struct.pack('<fff', n[0], n[1], n[2]))
            c = self.colors[i]
            col_bytes.extend(struct.pack('<fff', c[0], c[1], c[2]))

        primitives = []
        gltf_materials = []

        buffer_bytes = bytearray()
        buffer_bytes.extend(pos_bytes)
        pos_offset = 0
        pos_length = len(pos_bytes)

        norm_offset = len(buffer_bytes)
        buffer_bytes.extend(norm_bytes)
        norm_length = len(norm_bytes)

        col_offset = len(buffer_bytes)
        buffer_bytes.extend(col_bytes)
        col_length = len(col_bytes)

        buffer_views = [
            {"buffer": 0, "byteOffset": pos_offset, "byteLength": pos_length, "target": 34962},
            {"buffer": 0, "byteOffset": norm_offset, "byteLength": norm_length, "target": 34962},
            {"buffer": 0, "byteOffset": col_offset, "byteLength": col_length, "target": 34962}
        ]

        accessors = [
            {
                "bufferView": 0,
                "byteOffset": 0,
                "componentType": 5126,
                "count": len(self.vertices),
                "type": "VEC3",
                "max": max_pos if self.vertices else [0,0,0],
                "min": min_pos if self.vertices else [0,0,0]
            },
            {
                "bufferView": 1,
                "byteOffset": 0,
                "componentType": 5126,
                "count": len(self.normals),
                "type": "VEC3"
            },
            {
                "bufferView": 2,
                "byteOffset": 0,
                "componentType": 5126,
                "count": len(self.colors),
                "type": "VEC3"
            }
        ]

        for mat_name, faces in self.material_faces.items():
            if not faces:
                continue
            mat_idx = len(gltf_materials)
            diff = self.materials[mat_name]['diffuse']
            gltf_materials.append({
                "name": mat_name,
                "doubleSided": True,
                "pbrMetallicRoughness": {
                    "baseColorFactor": [diff[0], diff[1], diff[2], 1.0],
                    "metallicFactor": 0.05,
                    "roughnessFactor": 0.7
                }
            })

            cur_idx_bytes = bytearray()
            min_idx = 999999999
            max_idx = 0
            for f in faces:
                for idx in f:
                    min_idx = min(min_idx, idx)
                    max_idx = max(max_idx, idx)
                    cur_idx_bytes.extend(struct.pack('<I', idx))

            idx_offset = len(buffer_bytes)
            buffer_bytes.extend(cur_idx_bytes)
            idx_view = len(buffer_views)
            buffer_views.append({
                "buffer": 0,
                "byteOffset": idx_offset,
                "byteLength": len(cur_idx_bytes),
                "target": 34963
            })
            idx_acc = len(accessors)
            accessors.append({
                "bufferView": idx_view,
                "byteOffset": 0,
                "componentType": 5125,
                "count": len(faces) * 3,
                "type": "SCALAR",
                "max": [max_idx],
                "min": [min_idx]
            })

            primitives.append({
                "attributes": {
                    "POSITION": 0,
                    "NORMAL": 1,
                    "COLOR_0": 2
                },
                "indices": idx_acc,
                "material": mat_idx
            })

        # glTF dictionary referencing buffer 0 without a URI (GLB binary buffer)
        gltf_dict = {
            "asset": {"version": "2.0", "generator": "Tomato3D_Generator"},
            "scenes": [{"nodes": [0]}],
            "scene": 0,
            "nodes": [{"mesh": 0, "name": self.name}],
            "meshes": [{"name": self.name, "primitives": primitives}],
            "materials": gltf_materials,
            "accessors": accessors,
            "bufferViews": buffer_views,
            "buffers": [{"byteLength": len(buffer_bytes)}]
        }

        json_bytes = json.dumps(gltf_dict, separators=(',', ':')).encode('utf-8')
        pad_json = (4 - (len(json_bytes) % 4)) % 4
        json_bytes += b" " * pad_json

        pad_bin = (4 - (len(buffer_bytes) % 4)) % 4
        bin_chunk = bytes(buffer_bytes) + (b"\x00" * pad_bin)

        # Total file length = 12 (header) + 8 (json chunk hdr) + len(json_bytes) + 8 (bin chunk hdr) + len(bin_chunk)
        total_length = 12 + 8 + len(json_bytes) + 8 + len(bin_chunk)

        header = struct.pack('<4sII', b'glTF', 2, total_length)
        chunk0_hdr = struct.pack('<II', len(json_bytes), 0x4E4F534A) # JSON
        chunk1_hdr = struct.pack('<II', len(bin_chunk), 0x004E4942)  # BIN

        with open(filepath, "wb") as f:
            f.write(header)
            f.write(chunk0_hdr)
            f.write(json_bytes)
            f.write(chunk1_hdr)
            f.write(bin_chunk)

    def to_compact_dict(self):
        # Compact representation for client-side WebGL viewer
        flat_vertices = []
        for v in self.vertices:
            flat_vertices.extend([round(v[0], 4), round(v[1], 4), round(v[2], 4)])
        flat_normals = []
        for n in self.normals:
            flat_normals.extend([round(n[0], 3), round(n[1], 3), round(n[2], 3)])
        flat_colors = []
        for c in self.colors:
            flat_colors.extend([round(c[0], 3), round(c[1], 3), round(c[2], 3)])
        
        flat_faces = []
        for mat_name, faces in self.material_faces.items():
            for f in faces:
                flat_faces.extend([f[0], f[1], f[2]])
        return {
            "name": self.name,
            "vertices": flat_vertices,
            "normals": flat_normals,
            "colors": flat_colors,
            "indices": flat_faces,
            "materials": self.materials
        }

print("Base Mesh class defined successfully.")
