"""
Build ultra-compact interactive 3D WebGL viewer for Tomato Growth Stages.
Uses Int16 quantized positions (1mm precision) and Uint8 colors with OES_standard_derivatives.
Resulting total file size is under 90KB.
"""

import math
import json
import base64
import struct
import os
from generate_plants import build_stage1, build_stage2, build_stage3, init_materials, Mesh

def pack_mesh_int16(mesh):
    pos_bytes = bytearray()
    col_bytes = bytearray()
    
    for i, v in enumerate(mesh.vertices):
        # Quantize to millimeters (scale 1000)
        x = max(-32767, min(32767, int(round(v[0] * 1000.0))))
        y = max(-32767, min(32767, int(round(v[1] * 1000.0))))
        z = max(-32767, min(32767, int(round(v[2] * 1000.0))))
        pos_bytes.extend(struct.pack('<hhh', x, y, z))
        
        c = mesh.colors[i]
        r = max(0, min(255, int(c[0] * 255)))
        g = max(0, min(255, int(c[1] * 255)))
        b = max(0, min(255, int(c[2] * 255)))
        col_bytes.extend(struct.pack('BBB', r, g, b))
        
    return {
        "count": len(mesh.vertices),
        "pos": base64.b64encode(pos_bytes).decode('ascii'),
        "col": base64.b64encode(col_bytes).decode('ascii')
    }

def build_bench():
    mesh = Mesh("bench")
    init_materials(mesh)
    bx1, bx2 = -3.8, 3.8
    by1, by2 = -0.32, 0.0
    bz1, bz2 = -1.2, 1.2
    mesh.add_quad([bx1, by2, bz1], [bx2, by2, bz1], [bx2, by2, bz2], [bx1, by2, bz2], "bench_wood")
    mesh.add_quad([bx1, by1, bz2], [bx2, by1, bz2], [bx2, by2, bz2], [bx1, by2, bz2], "bench_wood")
    mesh.add_quad([bx2, by1, bz1], [bx1, by1, bz1], [bx1, by2, bz1], [bx2, by2, bz1], "bench_wood")
    mesh.add_quad([bx1, by1, bz1], [bx1, by1, bz2], [bx1, by2, bz2], [bx1, by2, bz1], "bench_wood")
    mesh.add_quad([bx2, by1, bz2], [bx2, by1, bz1], [bx2, by2, bz1], [bx2, by2, bz2], "bench_wood")
    return mesh

def get_viewer_html():
    st1 = build_stage1(center=(0, 0, 0))
    st2 = build_stage2(center=(0, 0, 0))
    st3 = build_stage3(center=(0, 0, 0))
    bench = build_bench()

    data = {
        "stage1": pack_mesh_int16(st1),
        "stage2": pack_mesh_int16(st2),
        "stage3": pack_mesh_int16(st3),
        "bench": pack_mesh_int16(bench)
    }
    data_json = json.dumps(data)

    template = """<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <title>3D Модель Помидора: 3 Этапа Роста</title>
  <script src="https://www.gstatic.com/antigravity/web/dev/tailwindcss.min.js"></script>
  <style>
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
      user-select: none;
      -webkit-user-select: none;
    }
    .stage-btn.active {
      background: #e07a5f;
      color: #ffffff;
      font-weight: 600;
      box-shadow: 0 2px 6px rgba(224, 122, 95, 0.35);
    }
  </style>
</head>
<body class="bg-transparent text-[var(--foreground)] antialiased p-0 m-0">
  <div class="max-w-4xl mx-auto space-y-2 py-1">
    <!-- Header & Stage Navigation -->
    <div class="flex flex-wrap items-center justify-between gap-2 pb-1.5 border-b border-[var(--card-border,#e2e8f0)] text-xs">
      <div class="flex items-center gap-2">
        <span class="text-lg">🍅</span>
        <h2 class="font-bold text-sm sm:text-base text-[var(--foreground)]">3D Помидор: 3 Этапа Роста</h2>
        <span class="px-1.5 py-0.5 rounded text-[10px] bg-emerald-500/10 text-emerald-600 font-medium border border-emerald-500/20">Low-Poly 3D</span>
      </div>

      <!-- Quick Switcher Tabs -->
      <div class="flex items-center gap-1 bg-[var(--card,#f1f5f9)] p-0.5 rounded-lg border border-[var(--card-border,#cbd5e1)]">
        <button id="btn-stage1" onclick="switchStage('stage1')" class="stage-btn px-2.5 py-1 rounded-md text-xs transition-colors">
          🌱 Росток
        </button>
        <button id="btn-stage2" onclick="switchStage('stage2')" class="stage-btn px-2.5 py-1 rounded-md text-xs transition-colors">
          🌿 Цветение
        </button>
        <button id="btn-stage3" onclick="switchStage('stage3')" class="stage-btn active px-2.5 py-1 rounded-md text-xs transition-colors">
          🍅 Урожай
        </button>
        <button id="btn-all" onclick="switchStage('all')" class="stage-btn px-2.5 py-1 rounded-md text-xs transition-colors">
          🪴 Все 3 вместе
        </button>
      </div>
    </div>

    <!-- 3D Interactive Viewport -->
    <div class="relative w-full rounded-xl overflow-hidden border border-[var(--card-border,#cbd5e1)] bg-gradient-to-b from-[#f8fafc] to-[#e2e8f0] dark:from-[#1e293b] dark:to-[#0f172a] shadow-sm" style="height: 310px;">
      <canvas id="glcanvas" class="w-full h-full cursor-grab active:cursor-grabbing block"></canvas>

      <!-- Overlay Badges -->
      <div class="absolute top-2.5 left-2.5 flex flex-col gap-1 z-10 pointer-events-none">
        <div id="badge-title" class="px-2.5 py-0.5 rounded-md bg-black/65 backdrop-blur-md text-white text-xs font-semibold flex items-center gap-1.5 shadow">
          <span>🍅</span> <span>Этап 3: Спелый урожай</span>
        </div>
        <div class="text-[10px] text-white/80 bg-black/45 backdrop-blur-sm px-2 py-0.5 rounded w-fit">
          🖱️ ЛКМ: вращать • Колесико: зум • ПКМ: панорама
        </div>
      </div>

      <!-- Viewport Controls -->
      <div class="absolute top-2.5 right-2.5 flex items-center gap-1 z-10">
        <button id="btn-rotate" onclick="toggleAutoRotate()" class="px-2 py-0.5 rounded-md bg-white/90 dark:bg-slate-800/90 text-[var(--foreground)] text-[11px] border border-black/10 shadow-sm flex items-center gap-1">
          <span id="rotate-icon">🔄</span> <span id="rotate-text">Автоповорот</span>
        </button>
        <button onclick="resetView()" class="p-1 rounded-md bg-white/90 dark:bg-slate-800/90 text-[var(--foreground)] text-[11px] border border-black/10 shadow-sm" title="Сброс камеры">
          🎯
        </button>
      </div>

      <!-- Growth Slider -->
      <div class="absolute bottom-2.5 left-1/2 -translate-x-1/2 bg-white/90 dark:bg-slate-800/90 backdrop-blur-md px-3 py-1 rounded-full border border-black/10 shadow-md flex items-center gap-2.5 z-10">
        <span class="text-[11px] text-[var(--muted-foreground)] font-medium">Стадия:</span>
        <input id="growth-slider" type="range" min="1" max="4" value="3" step="1" oninput="onSliderMove(this.value)" class="w-28 accent-[#e07a5f] cursor-pointer">
        <span id="slider-txt" class="text-xs font-bold text-[#e07a5f] min-w-[65px] text-center">3: Урожай</span>
      </div>
    </div>

    <!-- Info Bar & Stage Details -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-2 pt-0.5 text-xs">
      <div class="md:col-span-2 p-2.5 rounded-lg bg-[var(--card,#f8fafc)] border border-[var(--card-border,#e2e8f0)] space-y-1">
        <div class="flex items-center justify-between">
          <h3 id="info-title" class="font-bold text-[var(--foreground)]">Этап 3: Взрослый куст со спелыми помидорами</h3>
          <span id="info-poly" class="text-[10px] text-[var(--muted-foreground)] font-mono">1 162 полигонов</span>
        </div>
        <p id="info-desc" class="text-[var(--muted-foreground)] leading-relaxed text-[11px]">
          В точности соответствует крайнему левому горшку с вашего референса: 3 сочных глянцевых красных помидора с характерными 5-конечными резными чашелистиками, подвязка к бамбуковому колышку, сложные листья и цветущие побеги.
        </p>
        <div id="info-tags" class="flex flex-wrap gap-1 pt-0.5">
          <span class="px-1.5 py-0.2 rounded bg-red-500/10 text-red-600 font-medium text-[10px]">3 красных плода</span>
          <span class="px-1.5 py-0.2 rounded bg-amber-500/10 text-amber-700 font-medium text-[10px]">Колышек с подвязкой</span>
          <span class="px-1.5 py-0.2 rounded bg-emerald-500/10 text-emerald-700 font-medium text-[10px]">Сложные листья</span>
          <span class="px-1.5 py-0.2 rounded bg-orange-500/10 text-orange-700 font-medium text-[10px]">Горшок с личиком</span>
        </div>
      </div>

      <!-- Local Model Files Export -->
      <div class="p-2.5 rounded-lg bg-[var(--card,#f8fafc)] border border-[var(--card-border,#e2e8f0)] flex flex-col justify-between gap-1.5">
        <div>
          <h4 class="font-bold text-[var(--foreground)] text-[11px]">3D Файлы на диске:</h4>
          <p class="text-[10px] text-[var(--muted-foreground)]">Форматы <b>.GLB</b>, <b>.OBJ</b> и <b>.glTF</b> созданы в папке проекта:</p>
          <p class="text-[9px] font-mono text-[var(--muted-foreground)] truncate bg-black/5 dark:bg-white/5 px-1 py-0.5 rounded mt-0.5">
            scratch/tomato-3d-stages
          </p>
        </div>
        <button onclick="downloadCurrentObj()" class="w-full py-1.5 px-2 rounded-md bg-[#e07a5f] hover:bg-[#d66a48] text-white font-medium text-xs flex items-center justify-center gap-1 shadow-sm transition-colors">
          <span>💾</span> <span>Скачать текущий .OBJ</span>
        </button>
      </div>
    </div>
  </div>

  <script>
    const MODEL_BUFFERS = __DATA_JSON__;

    const STAGES = {
      stage1: {
        title: "Этап 1: Сеянец (Росток)",
        icon: "🌱",
        poly: "350 полигонов",
        desc: "Первые листочки помидора: тонкий нежный стебелёк, пара широких семядольных листьев и две крохотные пробивающиеся настоящие пластинки. Посажен в глиняный горшочек с личиком и румянцем.",
        tags: ["Семядоли", "Нежный росток", "Глиняный горшочек", "Низкополигональный"],
        dist: 4.8,
        target: [0, 1.8, 0],
        slider: 1
      },
      stage2: {
        title: "Этап 2: Подросший куст (Цветение)",
        icon: "🌿",
        poly: "614 полигонов",
        desc: "Куст окреп и пошёл в активный рост. Появился деревянный бамбуковый колышек с джутовыми подвязками. Сформированы боковые побеги со сложными резными листьями, ярко-жёлтые цветки и первая зелёная завязь помидорчика.",
        tags: ["Жёлтые цветки", "Зелёная завязь", "Бамбуковый колышек", "Ветвление"],
        dist: 5.6,
        target: [0, 2.2, 0],
        slider: 2
      },
      stage3: {
        title: "Этап 3: Взрослый куст со спелыми помидорами",
        icon: "🍅",
        poly: "1 162 полигонов",
        desc: "В точности соответствует крайнему левому горшку с вашего референса: 3 сочных глянцевых красных помидора с характерными 5-конечными резными чашелистиками, подвязка к бамбуковому колышку, сложные листья и цветущие побеги.",
        tags: ["3 красных плода", "Резные чашелистики", "Колышек с подвязкой", "Горшок с улыбкой"],
        dist: 6.8,
        target: [0, 2.6, 0],
        slider: 3
      },
      all: {
        title: "Все 3 этапа вместе на полке оранжереи",
        icon: "🪵",
        poly: "2 136 полигонов",
        desc: "Полная эволюция помидора в ряд на деревянной дощатой полке, как в солнечной оранжерее на вашем изображении: от крохотного ростка слева до сочного плодоносящего куста справа.",
        tags: ["Вся композиция", "Деревянная полка", "3 горшочка", "Сравнение масштабов"],
        dist: 9.2,
        target: [0, 1.8, 0],
        slider: 4
      }
    };

    let activeStage = 'stage3';
    let autoRotate = true;
    let yaw = 0.45;
    let pitch = 0.22;
    let distance = 6.8;
    let target = [0, 2.6, 0];

    let gl, prog;
    let gpuMeshes = {};
    let uProj, uView, uModel, uLightDir, uCamPos;

    function b64ToInt16Array(b64) {
      const bin = atob(b64);
      const bytes = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
      return new Int16Array(bytes.buffer);
    }

    function b64ToUint8Array(b64) {
      const bin = atob(b64);
      const bytes = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
      return bytes;
    }

    function initGL() {
      const canvas = document.getElementById('glcanvas');
      gl = canvas.getContext('webgl', { antialias: true, alpha: false });
      if (!gl) return;

      const ext = gl.getExtension('OES_standard_derivatives');

      const vs = `
        attribute vec3 aPos;
        attribute vec3 aCol;
        uniform mat4 uProj, uView, uModel;
        varying vec3 vWorldPos;
        varying vec3 vCol;
        void main() {
          vec3 realPos = aPos * 0.001;
          vec4 wp = uModel * vec4(realPos, 1.0);
          vWorldPos = wp.xyz;
          vCol = aCol;
          gl_Position = uProj * uView * wp;
        }
      `;

      const fs = `
        #extension GL_OES_standard_derivatives : enable
        precision mediump float;
        varying vec3 vWorldPos;
        varying vec3 vCol;
        uniform vec3 uLightDir, uCamPos;
        void main() {
          vec3 N = normalize(cross(dFdx(vWorldPos), dFdy(vWorldPos)));
          vec3 L = normalize(uLightDir);
          vec3 V = normalize(uCamPos - vWorldPos);
          vec3 H = normalize(L + V);

          float diff = max(dot(N, L), 0.0);
          float fill = max(dot(N, vec3(-0.4, 0.7, -0.4)), 0.0) * 0.35;
          float bounce = max(dot(N, vec3(0.0, -1.0, 0.0)), 0.0) * 0.18;
          vec3 ambient = vec3(0.38, 0.40, 0.44);

          float spec = pow(max(dot(N, H), 0.0), 32.0) * 0.38;
          vec3 light = ambient + vec3(1.0, 0.96, 0.88) * diff + vec3(0.6, 0.7, 0.85) * fill + vec3(0.35, 0.25, 0.2) * bounce;
          vec3 col = vCol * light + vec3(spec);
          gl_FragColor = vec4(col, 1.0);
        }
      `;

      function createShader(type, src) {
        const s = gl.createShader(type);
        gl.shaderSource(s, src);
        gl.compileShader(s);
        return s;
      }
      prog = gl.createProgram();
      gl.attachShader(prog, createShader(gl.VERTEX_SHADER, vs));
      gl.attachShader(prog, createShader(gl.FRAGMENT_SHADER, fs));
      gl.linkProgram(prog);
      gl.useProgram(prog);

      uProj = gl.getUniformLocation(prog, 'uProj');
      uView = gl.getUniformLocation(prog, 'uView');
      uModel = gl.getUniformLocation(prog, 'uModel');
      uLightDir = gl.getUniformLocation(prog, 'uLightDir');
      uCamPos = gl.getUniformLocation(prog, 'uCamPos');

      for (const [key, d] of Object.entries(MODEL_BUFFERS)) {
        const posArr = b64ToInt16Array(d.pos);
        const colArr = b64ToUint8Array(d.col);

        const posB = gl.createBuffer();
        gl.bindBuffer(gl.ARRAY_BUFFER, posB);
        gl.bufferData(gl.ARRAY_BUFFER, posArr, gl.STATIC_DRAW);

        const colB = gl.createBuffer();
        gl.bindBuffer(gl.ARRAY_BUFFER, colB);
        gl.bufferData(gl.ARRAY_BUFFER, colArr, gl.STATIC_DRAW);

        gpuMeshes[key] = {
          posBuf: posB,
          colBuf: colB,
          count: d.count,
          posData: posArr
        };
      }

      gl.enable(gl.DEPTH_TEST);
      gl.depthFunc(gl.LEQUAL);
      gl.clearColor(0.93, 0.95, 0.96, 1.0);

      setupInteractions(canvas);
      requestAnimationFrame(drawLoop);
    }

    function setupInteractions(canvas) {
      let isDown = false, isPan = false, lastX = 0, lastY = 0;
      canvas.addEventListener('mousedown', (e) => {
        isDown = true;
        isPan = (e.button === 2 || e.button === 1);
        lastX = e.clientX;
        lastY = e.clientY;
      });
      window.addEventListener('mouseup', () => { isDown = false; isPan = false; });
      canvas.addEventListener('contextmenu', (e) => e.preventDefault());

      window.addEventListener('mousemove', (e) => {
        if (!isDown) return;
        const dx = e.clientX - lastX;
        const dy = e.clientY - lastY;
        lastX = e.clientX;
        lastY = e.clientY;

        if (isPan) {
          const f = distance * 0.0018;
          target[0] -= dx * f * Math.cos(yaw) + dy * f * Math.sin(yaw) * Math.sin(pitch);
          target[1] += dy * f * Math.cos(pitch);
          target[2] -= dx * f * Math.sin(yaw);
        } else {
          yaw -= dx * 0.008;
          pitch = Math.max(-1.1, Math.min(1.2, pitch + dy * 0.008));
          autoRotate = false;
          updateRotateBtn();
        }
      });

      canvas.addEventListener('wheel', (e) => {
        e.preventDefault();
        distance = Math.max(2.5, Math.min(18.0, distance + e.deltaY * 0.006));
      }, { passive: false });

      let tX = 0, tY = 0, tDist = 0;
      canvas.addEventListener('touchstart', (e) => {
        if (e.touches.length === 1) {
          isDown = true;
          tX = e.touches[0].clientX;
          tY = e.touches[0].clientY;
        } else if (e.touches.length === 2) {
          tDist = Math.hypot(e.touches[0].clientX - e.touches[1].clientX, e.touches[0].clientY - e.touches[1].clientY);
        }
      });
      canvas.addEventListener('touchmove', (e) => {
        if (e.touches.length === 1 && isDown) {
          const dx = e.touches[0].clientX - tX;
          const dy = e.touches[0].clientY - tY;
          tX = e.touches[0].clientX;
          tY = e.touches[0].clientY;
          yaw -= dx * 0.01;
          pitch = Math.max(-1.1, Math.min(1.2, pitch + dy * 0.01));
          autoRotate = false;
          updateRotateBtn();
        } else if (e.touches.length === 2) {
          const d = Math.hypot(e.touches[0].clientX - e.touches[1].clientX, e.touches[0].clientY - e.touches[1].clientY);
          distance = Math.max(2.5, Math.min(18.0, distance - (d - tDist) * 0.02));
          tDist = d;
        }
      });
      canvas.addEventListener('touchend', () => { isDown = false; });
    }

    function switchStage(key) {
      activeStage = key;
      const s = STAGES[key];

      document.querySelectorAll('.stage-btn').forEach(b => b.classList.remove('active'));
      const btnId = key === 'all' ? 'btn-all' : 'btn-' + key;
      document.getElementById(btnId).classList.add('active');

      document.getElementById('badge-title').innerHTML = `<span>${s.icon}</span> <span>${s.title}</span>`;
      document.getElementById('info-title').innerText = s.title;
      document.getElementById('info-poly').innerText = s.poly;
      document.getElementById('info-desc').innerText = s.desc;
      document.getElementById('info-tags').innerHTML = s.tags.map(t => `<span class="px-1.5 py-0.2 rounded bg-emerald-500/10 text-emerald-700 font-medium text-[10px]">${t}</span>`).join('');

      document.getElementById('growth-slider').value = s.slider;
      document.getElementById('slider-txt').innerText = `${s.slider}: ${s.title.split(':')[0]}`;

      target = [...s.target];
      distance = s.dist;
    }

    function onSliderMove(val) {
      const map = { '1': 'stage1', '2': 'stage2', '3': 'stage3', '4': 'all' };
      switchStage(map[val]);
    }

    function toggleAutoRotate() {
      autoRotate = !autoRotate;
      updateRotateBtn();
    }

    function updateRotateBtn() {
      const btn = document.getElementById('btn-rotate');
      if (autoRotate) {
        btn.classList.add('bg-emerald-500/10', 'text-emerald-700', 'border-emerald-500/30');
        document.getElementById('rotate-text').innerText = 'Вращается';
      } else {
        btn.classList.remove('bg-emerald-500/10', 'text-emerald-700', 'border-emerald-500/30');
        document.getElementById('rotate-text').innerText = 'Автоповорот';
      }
    }

    function resetView() {
      const s = STAGES[activeStage];
      yaw = 0.45;
      pitch = 0.22;
      distance = s.dist;
      target = [...s.target];
      autoRotate = true;
      updateRotateBtn();
    }

    const pMat = new Float32Array(16);
    const vMat = new Float32Array(16);
    const mMat = new Float32Array(16);

    function mat4Identity(m) {
      for (let i = 0; i < 16; i++) m[i] = (i % 5 === 0) ? 1 : 0;
    }

    function mat4Translate(m, x, y, z) {
      m[12] += m[0]*x + m[4]*y + m[8]*z;
      m[13] += m[1]*x + m[5]*y + m[9]*z;
      m[14] += m[2]*x + m[6]*y + m[10]*z;
      m[15] += m[3]*x + m[7]*y + m[11]*z;
    }

    function mat4Perspective(out, fovy, aspect, near, far) {
      const f = 1.0 / Math.tan(fovy / 2);
      const nf = 1 / (near - far);
      out[0] = f / aspect; out[1] = 0; out[2] = 0; out[3] = 0;
      out[4] = 0; out[5] = f; out[6] = 0; out[7] = 0;
      out[8] = 0; out[9] = 0; out[10] = (far + near) * nf; out[11] = -1;
      out[12] = 0; out[13] = 0; out[14] = 2 * far * near * nf; out[15] = 0;
    }

    function mat4LookAt(out, eye, center, up) {
      let z0 = eye[0] - center[0], z1 = eye[1] - center[1], z2 = eye[2] - center[2];
      let len = 1 / Math.hypot(z0, z1, z2);
      z0 *= len; z1 *= len; z2 *= len;

      let x0 = up[1] * z2 - up[2] * z1, x1 = up[2] * z0 - up[0] * z2, x2 = up[0] * z1 - up[1] * z0;
      len = 1 / Math.hypot(x0, x1, x2);
      x0 *= len; x1 *= len; x2 *= len;

      let y0 = z1 * x2 - z2 * x1, y1 = z2 * x0 - z0 * x2, y2 = z0 * x1 - z1 * x0;

      out[0] = x0; out[1] = y0; out[2] = z0; out[3] = 0;
      out[4] = x1; out[5] = y1; out[6] = z1; out[7] = 0;
      out[8] = x2; out[9] = y2; out[10] = z2; out[11] = 0;
      out[12] = -(x0 * eye[0] + x1 * eye[1] + x2 * eye[2]);
      out[13] = -(y0 * eye[0] + y1 * eye[1] + y2 * eye[2]);
      out[14] = -(z0 * eye[0] + z1 * eye[1] + z2 * eye[2]);
      out[15] = 1;
    }

    function drawMesh(meshKey, offsetX = 0, offsetY = 0, offsetZ = 0) {
      const m = gpuMeshes[meshKey];
      if (!m) return;

      mat4Identity(mMat);
      if (offsetX !== 0 || offsetY !== 0 || offsetZ !== 0) {
        mat4Translate(mMat, offsetX, offsetY, offsetZ);
      }
      gl.uniformMatrix4fv(uModel, false, mMat);

      const aPos = gl.getAttribLocation(prog, 'aPos');
      gl.enableVertexAttribArray(aPos);
      gl.bindBuffer(gl.ARRAY_BUFFER, m.posBuf);
      gl.vertexAttribPointer(aPos, 3, gl.SHORT, false, 0, 0);

      const aCol = gl.getAttribLocation(prog, 'aCol');
      gl.enableVertexAttribArray(aCol);
      gl.bindBuffer(gl.ARRAY_BUFFER, m.colBuf);
      gl.vertexAttribPointer(aCol, 3, gl.UNSIGNED_BYTE, true, 0, 0);

      gl.drawArrays(gl.TRIANGLES, 0, m.count);
    }

    function drawLoop() {
      if (autoRotate) {
        yaw += 0.007;
      }

      const canvas = gl.canvas;
      const dpr = window.devicePixelRatio || 1;
      const w = Math.floor(canvas.clientWidth * dpr);
      const h = Math.floor(canvas.clientHeight * dpr);
      if (canvas.width !== w || canvas.height !== h) {
        canvas.width = w;
        canvas.height = h;
        gl.viewport(0, 0, w, h);
      }

      const eyeX = target[0] + distance * Math.cos(pitch) * Math.sin(yaw);
      const eyeY = target[1] + distance * Math.sin(pitch);
      const eyeZ = target[2] + distance * Math.cos(pitch) * Math.cos(yaw);

      mat4Perspective(pMat, Math.PI / 4, canvas.width / canvas.height, 0.1, 100.0);
      mat4LookAt(vMat, [eyeX, eyeY, eyeZ], target, [0, 1, 0]);

      gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
      gl.useProgram(prog);

      gl.uniformMatrix4fv(uProj, false, pMat);
      gl.uniformMatrix4fv(uView, false, vMat);
      gl.uniform3f(uLightDir, 0.6, 1.0, 0.5);
      gl.uniform3f(uCamPos, eyeX, eyeY, eyeZ);

      if (activeStage === 'all') {
        drawMesh('bench', 0, 0, 0);
        drawMesh('stage1', -2.3, 0, 0);
        drawMesh('stage2', 0, 0, 0);
        drawMesh('stage3', 2.3, 0, 0);
      } else {
        drawMesh(activeStage, 0, 0, 0);
      }

      requestAnimationFrame(drawLoop);
    }

    function downloadCurrentObj() {
      const meshKey = activeStage === 'all' ? 'stage3' : activeStage;
      const m = gpuMeshes[meshKey];
      if (!m) return;
      const pos = m.posData;
      let obj = `# Wavefront OBJ exported from Tomato3D\\n\\n`;
      for (let i = 0; i < pos.length; i += 3) {
        const x = (pos[i] * 0.001).toFixed(4);
        const y = (pos[i+1] * 0.001).toFixed(4);
        const z = (pos[i+2] * 0.001).toFixed(4);
        obj += `v ${x} ${y} ${z}\\n`;
      }
      for (let i = 0; i < m.count; i += 3) {
        obj += `f ${i+1} ${i+2} ${i+3}\\n`;
      }
      const blob = new Blob([obj], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `tomato_${activeStage}.obj`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }

    window.onload = initGL;
  </script>
</body>
</html>
"""
    return template.replace("__DATA_JSON__", data_json)

if __name__ == "__main__":
    html = get_viewer_html()
    out_path = r"C:\Users\user\.gemini\antigravity\scratch\tomato-3d-stages\tomato_3d_viewer.html"
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(html)
    print(f"Generated ultra-compact HTML viewer at {out_path} ({len(html)} chars)")
